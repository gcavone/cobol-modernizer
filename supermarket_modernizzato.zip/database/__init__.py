database/__init__.py

database/connection.py

from sqlalchemy import create_engine, Engine
from sqlalchemy.orm import sessionmaker, Session
from config import Config


class DatabaseConnection:
    """Manages database connection and session creation.
    
    Provides a singleton-like interface for obtaining database sessions.
    """

    _engine: Engine | None = None
    _session_factory: sessionmaker | None = None

    @classmethod
    def initialize(cls) -> None:
        """Initialize database connection and session factory.
        
        Should be called once at application startup.
        """
        if cls._engine is None:
            cls._engine = create_engine(
                Config.DATABASE_URL,
                echo=False,
                pool_pre_ping=True
            )
            cls._session_factory = sessionmaker(bind=cls._engine)

    @classmethod
    def get_session(cls) -> Session:
        """Get a new database session.
        
        Returns:
            SQLAlchemy Session instance.
        
        Raises:
            RuntimeError: If database not initialized.
        """
        if cls._session_factory is None:
            raise RuntimeError("Database not initialized. Call initialize() first.")
        return cls._session_factory()

    @classmethod
    def get_engine(cls) -> Engine:
        """Get the database engine.
        
        Returns:
            SQLAlchemy Engine instance.
        
        Raises:
            RuntimeError: If database not initialized.
        """
        if cls._engine is None:
            raise RuntimeError("Database not initialized. Call initialize() first.")
        return cls._engine

    @classmethod
    def close_session(cls, session: Session) -> None:
        """Close a database session.
        
        Args:
            session: The session to close.
        """
        if session:
            session.close()

database/init_db.py

from sqlalchemy.orm import sessionmaker
from config import Config
from database.connection import DatabaseConnection
from models.product import Product
from models.admin import Admin
from models.employee import Employee
from models.order import Order
from models.order_item import OrderItem
from models.salary_record import SalaryRecord
from models.profit_record import ProfitRecord
from models.activity_log import ActivityLog
from models.product import Base
from repositories.product_repository import ProductRepository
from repositories.admin_repository import AdminRepository
from repositories.employee_repository import EmployeeRepository
from services.auth_service import AuthService


def init_database() -> None:
    """Initialize database: create tables and seed default data.
    
    Creates all tables and populates with default admin, products, and employees.
    """
    DatabaseConnection.initialize()
    engine = DatabaseConnection.get_engine()

    Base.metadata.create_all(engine)
    print("✓ Database tables created successfully")

    Session = sessionmaker(bind=engine)
    session = Session()

    try:
        admin_repo = AdminRepository(session)
        default_email = "robby@gmail.com"

        if not admin_repo.get_by_email(default_email):
            password_hash = AuthService.hash_password("robby@123")
            admin_repo.create(
                email=default_email,
                password_hash=password_hash,
                is_active=True
            )
            print(f"✓ Default admin created: {default_email}")
        else:
            print(f"✓ Default admin already exists: {default_email}")

        product_repo = ProductRepository(session)
        sample_products = [
            {
                "code": "00000001",
                "name": "Canned Sardines",
                "unit": "155g",
                "price": 18.75
            },
            {
                "code": "00000002",
                "name": "Canned Sardines Spicy",
                "unit": "155g",
                "price": 18.75
            },
            {
                "code": "00000003",
                "name": "Condensed Milk",
                "unit": "300mL",
                "price": 53.00
            },
            {
                "code": "00000004",
                "name": "Evaporated Milk",
                "unit": "410mL",
                "price": 44.00
            },
            {
                "code": "00000005",
                "name": "Powdered Milk",
                "unit": "300g",
                "price": 96.25
            },
            {
                "code": "00000006",
                "name": "Cooking Oil",
                "unit": "1L",
                "price": 125.50
            },
            {
                "code": "00000007",
                "name": "Rice",
                "unit": "2kg",
                "price": 85.00
            },
            {
                "code": "00000008",
                "name": "Sugar",
                "unit": "1kg",
                "price": 45.00
            },
        ]

        created_count = 0
        for prod in sample_products:
            if not product_repo.get_by_code(prod["code"]):
                product_repo.create(**prod)
                created_count += 1

        print(f"✓ {created_count} sample products created")

        employee_repo = EmployeeRepository(session)
        sample_employees = [
            {
                "name": "Juan Dela Cruz",
                "employee_id": "EMP001",
                "hourly_rate": 500.00
            },
            {
                "name": "Maria Santos",
                "employee_id": "EMP002",
                "hourly_rate": 500.00
            },
            {
                "name": "Pedro Reyes",
                "employee_id": "EMP003",
                "hourly_rate": 550.00
            },
            {
                "name": "Ana Garcia",
                "employee_id": "EMP004",
                "hourly_rate": 500.00
            },
        ]

        created_emp_count = 0
        for emp in sample_employees:
            if not employee_repo.get_by_employee_id(emp["employee_id"]):
                employee_repo.create(**emp)
                created_emp_count += 1

        print(f"✓ {created_emp_count} sample employees created")

        print("\n✓ Database initialization completed successfully!")

    except Exception as e:
        print(f"✗ Error during database initialization: {str(e)}")
        raise
    finally:
        session.close()


if __name__ == "__main__":
    init_database()

main.py

import logging
import logging.handlers
from config import Config
from database.connection import DatabaseConnection
from database.init_db import init_database
from repositories.product_repository import ProductRepository
from repositories.admin_repository import AdminRepository
from repositories.employee_repository import EmployeeRepository
from repositories.order_repository import OrderRepository
from repositories.order_item_repository import OrderItemRepository
from repositories.salary_repository import SalaryRepository
from repositories.profit_repository import ProfitRepository
from repositories.activity_log_repository import ActivityLogRepository
from services.auth_service import AuthService
from services.product_service import ProductService
from services.employee_service import EmployeeService
from services.order_service import OrderService
from services.profit_service import ProfitService
from services.activity_service import ActivityService
from cli.main_menu import MainMenu
from cli.admin_menu import AdminMenu


def setup_logging() -> None:
    """Configure logging with rotating file handler.
    
    Sets up logging to both console and file with appropriate formatting.
    """
    import os
    os.makedirs("logs", exist_ok=True)

    logger: logging.Logger = logging.getLogger()
    logger.setLevel(Config.LOG_LEVEL)

    file_handler: logging.handlers.RotatingFileHandler = (
        logging.handlers.RotatingFileHandler(
            Config.LOG_FILE,
            maxBytes=10485760,
            backupCount=5
        )
    )
    file_handler.setLevel(Config.LOG_LEVEL)

    console_handler: logging.StreamHandler = logging.StreamHandler()
    console_handler.setLevel(logging.WARNING)

    formatter: logging.Formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    logger.info("Logging initialized")


def main() -> None:
    """Main application entry point.
    
    Initializes configuration, database, repositories, services,
    and starts the CLI interface.
    """
    try:
        Config.validate()

        setup_logging()
        logger: logging.Logger = logging.getLogger(__name__)
        logger.info("Application starting...")

        DatabaseConnection.initialize()
        logger.info("Database connection initialized")

        init_database()
        logger.info("Database initialized")

        session = DatabaseConnection.get_session()

        product_repo: ProductRepository = ProductRepository(session)
        admin_repo: AdminRepository = AdminRepository(session)
        employee_repo: EmployeeRepository = EmployeeRepository(session)
        order_repo: OrderRepository = OrderRepository(session)
        order_item_repo: OrderItemRepository = OrderItemRepository(session)
        salary_repo: SalaryRepository = SalaryRepository(session)
        profit_repo: ProfitRepository = ProfitRepository(session)
        activity_log_repo: ActivityLogRepository = ActivityLogRepository(session)

        logger.info("Repositories initialized")

        activity_service: ActivityService = ActivityService(activity_log_repo)
        auth_service: AuthService = AuthService(admin_repo)
        product_service: ProductService = ProductService(product_repo, activity_service)
        employee_service: EmployeeService = EmployeeService(
            employee_repo, salary_repo, activity_service
        )
        order_service: OrderService = OrderService(
            order_repo, order_item_repo, product_repo, activity_service
        )
        profit_service: ProfitService = ProfitService(profit_repo, activity_service)

        logger.info("Services initialized")

        main_menu: MainMenu = MainMenu(auth_service, product_service)
        
        original_admin_login = main_menu._admin_login
        
        def enhanced_admin_login():
            original_admin_login()
            admin_menu = AdminMenu(
                auth_service=auth_service,
                product_service=product_service,
                employee_service=employee_service,
                profit_service=profit_service
            )
        
        main_menu._admin_login = enhanced_admin_login

        main_menu.display()

        DatabaseConnection.close_session(session)
        logger.info("Application terminated normally")

    except ValueError as e:
        print(f"Configuration Error: {str(e)}")
        logging.error(f"Configuration error: {str(e)}")
        exit(1)
    except Exception as e:
        print(f"Fatal Error: {str(e)}")
        logging.error(f"Fatal error: {str(e)}", exc_info=True)
        exit(1)


if __name__ == "__main__":
    main()

.env

DB_HOST=localhost
DB_PORT=5432
DB_NAME=supermarket_db
DB_USER=postgres
DB_PASSWORD=your_secure_password
LOG_LEVEL=INFO
ADMIN_EMAIL=robby@gmail.com

requirements.txt

sqlalchemy==2.0.23
psycopg2-binary==2.9.9
bcrypt==4.1.1
python-dotenv==1.0.0
colorama==0.4.6