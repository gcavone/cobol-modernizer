# Supermarket Management System

## Descrizione del Progetto

Sistema di gestione per supermercati modernizzato da COBOL legacy a Python 3.11+ con PostgreSQL. Implementa gestione prodotti, calcolo stipendi dipendenti, calcolo profitti e modulo acquisti clienti con autenticazione sicura e persistenza completa dei dati.

## Architettura

### Livelli Applicativi

**Presentation Layer (CLI)**
- Menu interattivi per amministratori e clienti
- Validazione input basica
- Formattazione output (ricevute, tabelle)
- File: `cli/main_menu.py`, `cli/admin_menu.py`, `cli/buyer_menu.py`, `cli/product_menu.py`, `cli/employee_menu.py`, `cli/profit_menu.py`, `cli/order_menu.py`, `cli/ui_helpers.py`

**Service Layer**
- Logica di business (calcolo stipendi, profitti, ordini)
- Validazione dati
- Coordinamento tra repository
- Registrazione attività
- File: `services/auth_service.py`, `services/product_service.py`, `services/employee_service.py`, `services/order_service.py`, `services/profit_service.py`, `services/activity_service.py`

**Repository Layer**
- Astrazione accesso database
- CRUD generico e query specifiche
- Gestione transazioni
- File: `repositories/base_repository.py`, `repositories/product_repository.py`, `repositories/admin_repository.py`, `repositories/employee_repository.py`, `repositories/order_repository.py`, `repositories/order_item_repository.py`, `repositories/salary_repository.py`, `repositories/profit_repository.py`, `repositories/activity_log_repository.py`

**Model Layer**
- Entità dominio mappate a SQLAlchemy ORM
- Vincoli integrità database
- File: `models/product.py`, `models/admin.py`, `models/employee.py`, `models/order.py`, `models/order_item.py`, `models/salary_record.py`, `models/profit_record.py`, `models/activity_log.py`

**Configuration Layer**
- Variabili d'ambiente
- Connessione database
- Logging
- File: `config.py`, `.env`, `database/connection.py`, `database/init_db.py`

## Installazione

### Prerequisiti
- Python 3.11+
- PostgreSQL 12+
- pip

### Step-by-step

1. **Clone repository**
```bash
git clone <repository-url>
cd supermarket_system
```

2. **Crea file .env**
```bash
cp .env.example .env
```
Modifica `.env` con credenziali PostgreSQL:
```
DB_HOST=localhost
DB_PORT=5432
DB_NAME=supermarket_db
DB_USER=postgres
DB_PASSWORD=your_secure_password
LOG_LEVEL=INFO
ADMIN_EMAIL=robby@gmail.com
```

3. **Installa dipendenze**
```bash
pip install -r requirements.txt
```

4. **Inizializza database**
```bash
python database/init_db.py
```
Questo crea tutte le tabelle e popola con dati di default (admin, prodotti, dipendenti).

5. **Avvia applicazione**
```bash
python main.py
```

## Utilizzo

### Login Amministratore
1. Seleziona "1) Administrator" dal menu principale
2. Email: `robby@gmail.com`
3. Password: `robby@123`
4. Accedi a menu amministratore

### Menu Amministratore
- **1) Employee Salary** - Calcola stipendi dipendenti (SALARY = HOURLY_RATE × HOURS_WORKED)
- **2) Manage Products** - CRUD prodotti (codice 8 cifre, nome, unità, prezzo)
- **3) Calculate Profit** - Calcola profitti (PROFIT = SELLING_PRICE - COGS)
- **4) Logout** - Esci

### Menu Buyer
1. Seleziona "2) Buyer" dal menu principale
2. **1) View Products** - Visualizza catalogo
3. **2) Create Order** - Crea ordine:
   - Seleziona prodotti per codice
   - Inserisci quantità
   - Visualizza totale
   - Inserisci importo pagato
   - Ricevi resto (CHANGE = PAYMENT - TOTAL)
4. **3) Exit** - Esci

## Miglioramenti rispetto al Legacy COBOL

### Sicurezza Credenziali
- ✅ Password hashata con bcrypt (non hardcodata)
- ✅ Credenziali caricate da variabili d'ambiente
- ✅ Confronto sicuro password

### Integrità Dati
- ✅ Database relazionale PostgreSQL (non file piatto)
- ✅ Vincoli PRIMARY KEY, UNIQUE, FOREIGN KEY, CHECK
- ✅ Transazioni atomiche
- ✅ Nessun file corrotto

### Validazione Input
- ✅ Validazione robusta a livello service
- ✅ Range, formato, unicità controllati
- ✅ Messaggi errore chiari

### Eliminazione Duplicazione
- ✅ Funzioni riutilizzabili (ask_continue, print_table)
- ✅ DRY principle applicato
- ✅ Codice leggibile e manutenibile

### Persistenza Completa
- ✅ Tutti gli ordini salvati nel database
- ✅ Timestamp su ogni operazione
- ✅ Nessun dato perso

### Audit Trail
- ✅ Tabella activity_logs con tutte le azioni
- ✅ Logging file con timestamp
- ✅ Tracciabilità completa

### Scalabilità
- ✅ Nessun limite fisso di record
- ✅ Database supporta milioni di ordini
- ✅ Pronto per API REST o web

### Manutenibilità
- ✅ Codice Python leggibile
- ✅ Type hints ovunque
- ✅ Docstring Google-style
- ✅ Separazione responsabilità

## Struttura Progetto

```
supermarket_system/
├── main.py                          # Entry point
├── config.py                        # Configurazione
├── requirements.txt                 # Dipendenze
├── .env                             # Variabili d'ambiente
├── .env.example                     # Template .env
├── README.md                        # Documentazione
│
├── models/
│   ├── __init__.py
│   ├── product.py
│   ├── admin.py
│   ├── employee.py
│   ├── order.py
│   ├── order_item.py
│   ├── salary_record.py
│   ├── profit_record.py
│   └── activity_log.py
│
├── repositories/
│   ├── __init__.py
│   ├── base_repository.py
│   ├── product_repository.py
│   ├── admin_repository.py
│   ├── employee_repository.py
│   ├── order_repository.py
│   ├── order_item_repository.py
│   ├── salary_repository.py
│   ├── profit_repository.py
│   └── activity_log_repository.py
│
├── services/
│   ├── __init__.py
│   ├── auth_service.py
│   ├── product_service.py
│   ├── employee_service.py
│   ├── order_service.py
│   ├── profit_service.py
│   └── activity_service.py
│
├── cli/
│   ├── __init__.py
│   ├── main_menu.py
│   ├── admin_menu.py
│   ├── buyer_menu.py
│   ├── product_menu.py
│   ├── employee_menu.py
│   ├── profit_menu.py
│   ├── order_menu.py
│   └── ui_helpers.py
│
├── database/
│   ├── __init__.py
│   ├── connection.py
│   └── init_db.py
│
└── logs/
    └── app.log
```

## Credenziali di Default

**Admin Account**
- Email: `robby@gmail.com`
- Password: `robby@123`

**Sample Products**
- 00000001: Canned Sardines (155g) - ₱18.75
- 00000002: Canned Sardines Spicy (155g) - ₱18.75
- 00000003: Condensed Milk (300mL) - ₱53.00
- 00000004: Evaporated Milk (410mL) - ₱44.00
- 00000005: Powdered Milk (300g) - ₱96.25
- 00000006: Cooking Oil (1L) - ₱125.50
- 00000007: Rice (2kg) - ₱85.00
- 00000008: Sugar (1kg) - ₱45.00

**Sample Employees**
- EMP001: Juan Dela Cruz - ₱500.00/hour
- EMP002: Maria Santos - ₱500.00/hour
- EMP003: Pedro Reyes - ₱550.00/hour
- EMP004: Ana Garcia - ₱500.00/hour

## Business Rules Implementate

- **SALARY = HOURLY_RATE × HOURS_WORKED** → `EmployeeService.calculate_salary()`
- **PROFIT = SELLING_PRICE - COGS** → `ProfitService.calculate_profit()`
- **CHANGE = PAYMENT - TOTAL** → `OrderService.calculate_change()`
- **Autenticazione** → `AuthService.authenticate()` con bcrypt
- **CRUD Prodotti** → `ProductService` con validazione codice 8 cifre

## Logging

Tutti gli eventi registrati in:
- **File**: `logs/app.log` (rotating, max 10MB)
- **Database**: Tabella `activity_logs`

Livello log configurabile in `.env` (default: INFO)

## Supporto

Per problemi o domande, consultare la documentazione dell'architettura nel file ARCHITETTURA.md