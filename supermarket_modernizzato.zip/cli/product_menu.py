import logging
from typing import List
from services.product_service import ProductService
from cli.ui_helpers import clear_screen, print_header, ask_continue, print_table, format_currency


class ProductMenu:
    """Product management menu for administrators.
    
    Provides CRUD operations for product inventory.
    """

    def __init__(self, product_service: ProductService, admin_id: int) -> None:
        """Initialize ProductMenu with required services.
        
        Args:
            product_service: Service for product management.
            admin_id: ID of logged-in administrator.
        """
        self.product_service: ProductService = product_service
        self.admin_id: int = admin_id
        self.logger: logging.Logger = logging.getLogger(__name__)

    def display(self) -> None:
        """Display product menu and handle selections.
        
        Loops until user chooses to exit.
        """
        while True:
            clear_screen()
            print_header("PRODUCT MANAGEMENT")

            print("\n1) View Products")
            print("2) Add Product")
            print("3) Delete Product")
            print("4) Search Product")
            print("5) Back to Admin Menu")

            choice: str = input("\nSelect option: ").strip()

            if choice == "1":
                self.view_products()
            elif choice == "2":
                self.add_product()
            elif choice == "3":
                self.delete_product()
            elif choice == "4":
                self.search_product()
            elif choice == "5":
                break
            else:
                print("\n❌ Invalid choice. Please select 1-5.")
                input("Press Enter to continue...")

    def view_products(self) -> None:
        """Display all products in a formatted table."""
        clear_screen()
        print_header("PRODUCT LIST")

        try:
            products = self.product_service.get_all_products()

            if not products:
                print("\nNo products found.")
                input("Press Enter to continue...")
                return

            headers: List[str] = ["ID", "Code", "Name", "Unit", "Price"]
            rows: List[List[str]] = [
                [
                    str(p.id),
                    p.code,
                    p.name,
                    p.unit,
                    format_currency(float(p.price))
                ]
                for p in products
            ]

            print()
            print_table(headers, rows)
            input("\nPress Enter to continue...")

        except Exception as e:
            print(f"\n❌ Error loading products: {str(e)}")
            self.logger.error(f"Error in view_products: {str(e)}")
            input("Press Enter to continue...")

    def add_product(self) -> None:
        """Add a new product."""
        clear_screen()
        print_header("ADD NEW PRODUCT")

        try:
            code: str = input("\nProduct Code (8 digits): ").strip()
            name: str = input("Product Name: ").strip()
            unit: str = input("Unit of Measurement: ").strip()

            try:
                price: float = float(input("Price: "))
            except ValueError:
                print("❌ Invalid price format")
                input("Press Enter to continue...")
                return

            product = self.product_service.create_product(
                code=code,
                name=name,
                unit=unit,
                price=price,
                admin_id=self.admin_id
            )

            print(f"\n✓ Product created successfully!")
            print(f"  Code: {product.code}")
            print(f"  Name: {product.name}")
            print(f"  Unit: {product.unit}")
            print(f"  Price: {format_currency(float(product.price))}")

            if ask_continue("\nAdd another product? [Y/N]: "):
                self.add_product()

        except ValueError as e:
            print(f"\n❌ Error: {str(e)}")
            self.logger.warning(f"Product creation failed: {str(e)}")
            input("Press Enter to continue...")
        except Exception as e:
            print(f"\n❌ Unexpected error: {str(e)}")
            self.logger.error(f"Error in add_product: {str(e)}")
            input("Press Enter to continue...")

    def delete_product(self) -> None:
        """Delete a product."""
        clear_screen()
        print_header("DELETE PRODUCT")

        try:
            products = self.product_service.get_all_products()
            if not products:
                print("\nNo products to delete.")
                input("Press Enter to continue...")
                return

            try:
                product_id: int = int(input("\nEnter Product ID to delete: "))
            except ValueError:
                print("❌ Invalid product ID")
                input("Press Enter to continue...")
                return

            product = self.product_service.get_product_by_id(product_id)

            print(f"\nProduct to delete:")
            print(f"  Code: {product.code}")
            print(f"  Name: {product.name}")
            print(f"  Unit: {product.unit}")
            print(f"  Price: {format_currency(float(product.price))}")

            if ask_continue("\nAre you sure you want to delete this product? [Y/N]: "):
                self.product_service.delete_product(product_id, self.admin_id)
                print("\n✓ Product deleted successfully!")
                self.logger.info(f"Product {product_id} deleted by admin {self.admin_id}")

            input("Press Enter to continue...")

        except ValueError as e:
            print(f"\n❌ Error: {str(e)}")
            self.logger.warning(f"Product deletion failed: {str(e)}")
            input("Press Enter to continue...")
        except Exception as e:
            print(f"\n❌ Unexpected error: {str(e)}")
            self.logger.error(f"Error in delete_product: {str(e)}")
            input("Press Enter to continue...")

    def search_product(self) -> None:
        """Search for products by name."""
        clear_screen()
        print_header("SEARCH PRODUCTS")

        try:
            search_term: str = input("\nEnter product name to search: ").strip()

            if not search_term:
                print("❌ Search term cannot be empty")
                input("Press Enter to continue...")
                return

            products = self.product_service.search_products_by_name(search_term)

            if not products:
                print(f"\nNo products found matching '{search_term}'")
                input("Press Enter to continue...")
                return

            headers: List[str] = ["ID", "Code", "Name", "Unit", "Price"]
            rows: List[List[str]] = [
                [
                    str(p.id),
                    p.code,
                    p.name,
                    p.unit,
                    format_currency(float(p.price))
                ]
                for p in products
            ]

            print()
            print_table(headers, rows)
            input("\nPress Enter to continue...")

        except Exception as e:
            print(f"\n❌ Error: {str(e)}")
            self.logger.error(f"Error in search_product: {str(e)}")
            input("Press Enter to continue...")

import logging
from typing import List
from services.employee_service import EmployeeService
from cli.ui_helpers import clear_screen, print_header, ask_continue, print_table, format_currency


class EmployeeMenu:
    """Employee management menu for administrators.
    
    Provides employee CRUD and salary calculation operations.
    """

    def __init__(self, employee_service: EmployeeService, admin_id: int) -> None:
        """Initialize EmployeeMenu with required services.
        
        Args:
            employee_service: Service for employee management.
            admin_id: ID of logged-in administrator.
        """
        self.employee_service: EmployeeService = employee_service
        self.admin_id: int = admin_id
        self.logger: logging.Logger = logging.getLogger(__name__)

    def display(self) -> None:
        """Display employee menu and handle selections.
        
        Loops until user chooses to exit.
        """
        while True:
            clear_screen()
            print_header("EMPLOYEE MANAGEMENT")

            print("\n1) List Employees")
            print("2) Add Employee")
            print("3) Calculate Salary")
            print("4) Back to Admin Menu")

            choice: str = input("\nSelect option: ").strip()

            if choice == "1":
                self.list_employees()
            elif choice == "2":
                self.add_employee()
            elif choice == "3":
                self.calculate_salary()
            elif choice == "4":
                break
            else:
                print("\n❌ Invalid choice. Please select 1-4.")
                input("Press Enter to continue...")

    def list_employees(self) -> None:
        """Display all employees in a formatted table."""
        clear_screen()
        print_header("EMPLOYEE LIST")

        try:
            employees = self.employee_service.list_all_employees()

            if not employees:
                print("\nNo employees found.")
                input("Press Enter to continue...")
                return

            headers: List[str] = ["ID", "Name", "Employee ID", "Hourly Rate"]
            rows: List[List[str]] = [
                [
                    str(e.id),
                    e.name,
                    e.employee_id,
                    format_currency(float(e.hourly_rate))
                ]
                for e in employees
            ]

            print()
            print_table(headers, rows)
            input("\nPress Enter to continue...")

        except Exception as e:
            print(f"\n❌ Error loading employees: {str(e)}")
            self.logger.error(f"Error in list_employees: {str(e)}")
            input("Press Enter to continue...")

    def add_employee(self) -> None:
        """Add a new employee."""
        clear_screen()
        print_header("ADD NEW EMPLOYEE")

        try:
            name: str = input("\nEmployee Name: ").strip()
            employee_id: str = input("Employee ID: ").strip()

            hourly_rate_input: str = input("Hourly Rate (default 500.00): ").strip()
            hourly_rate: float = 500.0

            if hourly_rate_input:
                try:
                    hourly_rate = float(hourly_rate_input)
                except ValueError:
                    print("❌ Invalid hourly rate format")
                    input("Press Enter to continue...")
                    return

            employee = self.employee_service.create_employee(
                name=name,
                employee_id=employee_id,
                hourly_rate=hourly_rate
            )

            print(f"\n✓ Employee created successfully!")
            print(f"  Name: {employee.name}")
            print(f"  Employee ID: {employee.employee_id}")
            print(f"  Hourly Rate: {format_currency(float(employee.hourly_rate))}")

            if ask_continue("\nAdd another employee? [Y/N]: "):
                self.add_employee()

        except ValueError as e:
            print(f"\n❌ Error: {str(e)}")
            self.logger.warning(f"Employee creation failed: {str(e)}")
            input("Press Enter to continue...")
        except Exception as e:
            print(f"\n❌ Unexpected error: {str(e)}")
            self.logger.error(f"Error in add_employee: {str(e)}")
            input("Press Enter to continue...")

    def calculate_salary(self) -> None:
        """Calculate salary for an employee.
        
        Implements: SALARY = HOURLY_RATE × HOURS_WORKED
        """
        clear_screen()
        print_header("CALCULATE SALARY")

        try:
            employees = self.employee_service.list_all_employees()
            if not employees:
                print("\nNo employees found.")
                input("Press Enter to continue...")
                return

            print("\nAvailable Employees:")
            for e in employees:
                print(f"  ID {e.id}: {e.name} ({e.employee_id}) - {format_currency(float(e.hourly_rate))}/hour")

            try:
                employee_id: int = int(input("\nEnter Employee ID: "))
            except ValueError:
                print("❌ Invalid employee ID")
                input("Press Enter to continue...")
                return

            employee = self.employee_service.get_employee_by_id(employee_id)

            try:
                hours_worked: float = float(input("Hours Worked: "))
            except ValueError:
                print("❌ Invalid hours format")
                input("Press Enter to continue...")
                return

            salary_record = self.employee_service.calculate_salary(
                employee_id=employee_id,
                hours_worked=hours_worked,
                admin_id=self.admin_id
            )

            print(f"\n✓ Salary calculated successfully!")
            print(f"  Employee: {employee.name}")
            print(f"  Hours Worked: {salary_record.hours_worked}")
            print(f"  Hourly Rate: {format_currency(float(salary_record.hourly_rate))}")
            print(f"  Total Salary: {format_currency(float(salary_record.total_salary))}")

            if ask_continue("\nCalculate another salary? [Y/N]: "):
                self.calculate_salary()

        except ValueError as e:
            print(f"\n❌ Error: {str(e)}")
            self.logger.warning(f"Salary calculation failed: {str(e)}")
            input("Press Enter to continue...")
        except Exception as e:
            print(f"\n❌ Unexpected error: {str(e)}")
            self.logger.error(f"Error in calculate_salary: {str(e)}")
            input("Press Enter to continue...")

import logging
from typing import List
from services.profit_service import ProfitService
from cli.ui_helpers import clear_screen, print_header, ask_continue, print_table, format_currency


class ProfitMenu:
    """Profit management menu for administrators.
    
    Provides profit calculation and viewing operations.
    """

    def __init__(self, profit_service: ProfitService, admin_id: int) -> None:
        """Initialize ProfitMenu with required services.
        
        Args:
            profit_service: Service for profit calculation.
            admin_id: ID of logged-in administrator.
        """
        self.profit_service: ProfitService = profit_service
        self.admin_id: int = admin_id
        self.logger: logging.Logger = logging.getLogger(__name__)

    def display(self) -> None:
        """Display profit menu and handle selections.
        
        Loops until user chooses to exit.
        """
        while True:
            clear_screen()
            print_header("PROFIT MANAGEMENT")

            print("\n1) Calculate Profit")
            print("2) View Profit History")
            print("3) Back to Admin Menu")

            choice: str = input("\nSelect option: ").strip()

            if choice == "1":
                self.calculate_profit()
            elif choice == "2":
                self.list_profits()
            elif choice == "3":
                break
            else:
                print("\n❌ Invalid choice. Please select 1-3.")
                input("Press Enter to continue...")

    def calculate_profit(self) -> None:
        """Calculate profit.
        
        Implements: PROFIT = SELLING_PRICE - COGS
        """
        clear_screen()
        print_header("CALCULATE PROFIT")

        try:
            try:
                cogs: float = float(input("\nCost of Goods Sold (COGS): "))
            except ValueError:
                print("❌ Invalid COGS format")
                input("Press Enter to continue...")
                return

            try:
                selling_price: float = float(input("Selling Price: "))
            except ValueError:
                print("❌ Invalid selling price format")
                input("Press Enter to continue...")
                return

            profit_record = self.profit_service.calculate_profit(
                cogs=cogs,
                selling_price=selling_price,
                admin_id=self.admin_id
            )

            print(f"\n✓ Profit calculated successfully!")
            print(f"  COGS: {format_currency(float(profit_record.cogs))}")
            print(f"  Selling Price: {format_currency(float(profit_record.selling_price))}")
            print(f"  Profit: {format_currency(float(profit_record.profit))}")

            if ask_continue("\nCalculate another profit? [Y/N]: "):
                self.calculate_profit()

        except ValueError as e:
            print(f"\n❌ Error: {str(e)}")
            self.logger.warning(f"Profit calculation failed: {str(e)}")
            input("Press Enter to continue...")
        except Exception as e:
            print(f"\n❌ Unexpected error: {str(e)}")
            self.logger.error(f"Error in calculate_profit: {str(e)}")
            input("Press Enter to continue...")

    def list_profits(self) -> None:
        """Display all profit records in a formatted table."""
        clear_screen()
        print_header("PROFIT HISTORY")

        try:
            profits = self.profit_service.list_all_profits()

            if not profits:
                print("\nNo profit records found.")
                input("Press Enter to continue...")
                return

            headers: List[str] = ["ID", "COGS", "Selling Price", "Profit", "Date"]
            rows: List[List[str]] = [
                [
                    str(p.id),
                    format_currency(float(p.cogs)),
                    format_currency(float(p.selling_price)),
                    format_currency(float(p.profit)),
                    str(p.created_at)
                ]
                for p in profits
            ]

            print()
            print_table(headers, rows)
            input("\nPress Enter to continue...")

        except Exception as e:
            print(f"\n❌ Error loading profit records: {str(e)}")
            self.logger.error(f"Error in list_profits: {str(e)}")
            input("Press Enter to continue...")

import logging
from typing import List
from services.order_service import OrderService
from cli.ui_helpers import clear_screen, print_header, print_table, format_currency


class OrderMenu:
    """Order viewing menu for administrators.
    
    Provides order history and receipt viewing operations.
    """

    def __init__(self, order_service: OrderService) -> None:
        """Initialize OrderMenu with required services.
        
        Args:
            order_service: Service for order management.
        """
        self.order_service: OrderService = order_service
        self.logger: logging.Logger = logging.getLogger(__name__)

    def display(self) -> None:
        """Display order menu and handle selections.
        
        Loops until user chooses to exit.
        """
        while True:
            clear_screen()
            print_header("ORDER MANAGEMENT")

            print("\n1) View All Orders")
            print("2) View Order Receipt")
            print("3) Back to Admin Menu")

            choice: str = input("\nSelect option: ").strip()

            if choice == "1":
                self.list_orders()
            elif choice == "2":
                self.view_order_receipt()
            elif choice == "3":
                break
            else:
                print("\n❌ Invalid choice. Please select 1-3.")
                input("Press Enter to continue...")

    def list_orders(self) -> None:
        """Display all orders in a formatted table."""
        clear_screen()
        print_header("ORDER HISTORY")

        try:
            orders = self.order_service.list_all_orders()

            if not orders:
                print("\nNo orders found.")
                input("Press Enter to continue...")
                return

            headers: List[str] = ["Order #", "Total", "Paid", "Change", "Date"]
            rows: List[List[str]] = [
                [
                    o.order_number,
                    format_currency(float(o.total_amount)),
                    format_currency(float(o.payment_amount)),
                    format_currency(float(o.change_amount)),
                    str(o.created_at)
                ]
                for o in orders
            ]

            print()
            print_table(headers, rows)
            input("\nPress Enter to continue...")

        except Exception as e:
            print(f"\n❌ Error loading orders: {str(e)}")
            self.logger.error(f"Error in list_orders: {str(e)}")
            input("Press Enter to continue...")

    def view_order_receipt(self) -> None:
        """Display a specific order receipt."""
        clear_screen()
        print_header("VIEW ORDER RECEIPT")

        try:
            try:
                order_id: int = int(input("\nEnter Order ID: "))
            except ValueError:
                print("❌ Invalid order ID")
                input("Press Enter to continue...")
                return

            receipt = self.order_service.get_order_receipt(order_id)

            self._print_receipt(receipt)

        except ValueError as e:
            print(f"\n❌ Error: {str(e)}")
            self.logger.warning(f"Receipt retrieval failed: {str(e)}")
            input("Press Enter to continue...")
        except Exception as e:
            print(f"\n❌ Unexpected error: {str(e)}")
            self.logger.error(f"Error in view_order_receipt: {str(e)}")
            input("Press Enter to continue...")

    def _print_receipt(self, receipt: dict) -> None:
        """Print order receipt.
        
        Args:
            receipt: Dictionary with order details.
        """
        clear_screen()
        print("=" * 70)
        print("RECEIPT".center(70))
        print("=" * 70)

        print(f"\nOrder Number: {receipt['order_number']}")
        print(f"Date/Time: {receipt['created_at']}")

        print("\n" + "-" * 70)
        print("Items:")
        print("-" * 70)

        for item in receipt["items"]:
            print(
                f"Product ID {item.product_id:3} x{item.quantity:3} @ {format_currency(float(item.unit_price)):>10} = {format_currency(float(item.subtotal)):>10}"
            )

        print("-" * 70)
        print(f"Total Amount:    {format_currency(receipt['total_amount']):>55}")
        print(f"Amount Paid:     {format_currency(receipt['payment_amount']):>55}")
        print(f"Change:          {format_currency(receipt['change_amount']):>55}")
        print("=" * 70)
        print("THANK YOU FOR SHOPPING!".center(70))
        print("=" * 70)

        input("\nPress Enter to continue...")

import logging
import logging.handlers
from config import Config
from database.connection import DatabaseConnection
from database.init_db import init_database
from repositories.product_repository import ProductRepository
from repositories.admin_repository import AdminRepository
from repositories.employee_repository import EmployeeRepository
from repositories.order_repository import OrderRepository
from repositories.order_item_repository import OrderItemRepository
from repositories.salary_repository import SalaryRepository
from repositories.profit_repository import ProfitRepository
from repositories.activity_log_repository import ActivityLogRepository
from services.auth_service import AuthService
from services.product_service import ProductService
from services.employee_service import EmployeeService
from services.order_service import OrderService
from services.profit_service import ProfitService
from services.activity_service import ActivityService
from cli.main_menu import MainMenu


def setup_logging() -> None:
    """Configure logging with rotating file handler.
    
    Sets up logging to both console and file with appropriate formatting.
    """
    import os
    os.makedirs("logs", exist_ok=True)

    logger: logging.Logger = logging.getLogger()
    logger.setLevel(Config.LOG_LEVEL)

    file_handler: logging.handlers.RotatingFileHandler = (
        logging.handlers.RotatingFileHandler(
            Config.LOG_FILE,
            maxBytes=10485760,
            backupCount=5
        )
    )
    file_handler.setLevel(Config.LOG_LEVEL)

    console_handler: logging.StreamHandler = logging.StreamHandler()
    console_handler.setLevel(logging.WARNING)

    formatter: logging.Formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    logger.info("Logging initialized")


def main() -> None:
    """Main application entry point.
    
    Initializes configuration, database, repositories, services,
    and starts the CLI interface.
    """
    try:
        Config.validate()

        setup_logging()
        logger: logging.Logger = logging.getLogger(__name__)
        logger.info("Application starting...")

        DatabaseConnection.initialize()
        logger.info("Database connection initialized")

        init_database()
        logger.info("Database initialized")

        session = DatabaseConnection.get_session()

        product_repo: ProductRepository = ProductRepository(session)
        admin_repo: AdminRepository = AdminRepository(session)
        employee_repo: EmployeeRepository = EmployeeRepository(session)
        order_repo: OrderRepository = OrderRepository(session)
        order_item_repo: OrderItemRepository = OrderItemRepository(session)
        salary_repo: SalaryRepository = SalaryRepository(session)
        profit_repo: ProfitRepository = ProfitRepository(session)
        activity_log_repo: ActivityLogRepository = ActivityLogRepository(session)

        logger.info("Repositories initialized")

        activity_service: ActivityService = ActivityService(activity_log_repo)
        auth_service: AuthService = AuthService(admin_repo)
        product_service: ProductService = ProductService(product_repo, activity_service)
        employee_service: EmployeeService = EmployeeService(
            employee_repo, salary_repo, activity_service
        )
        order_service: OrderService = OrderService(
            order_repo, order_item_repo, product_repo, activity_service
        )
        profit_service: ProfitService = ProfitService(profit_repo, activity_service)

        logger.info("Services initialized")

        main_menu: MainMenu = MainMenu(auth_service, product_service)
        
        main_menu.auth_service = auth_service
        main_menu.product_service = product_service

        from cli.admin_menu import AdminMenu
        AdminMenu.__init__.__defaults__ = (None, None, None, None)

        main_menu.display()

        DatabaseConnection.close_session(session)
        logger.info("Application terminated normally")

    except ValueError as e:
        print(f"Configuration Error: {str(e)}")
        logging.error(f"Configuration error: {str(e)}")
        exit(1)
    except Exception as e:
        print(f"Fatal Error: {str(e)}")
        logging.error(f"Fatal error: {str(e)}", exc_info=True)
        exit(1)


if __name__ == "__main__":
    main()