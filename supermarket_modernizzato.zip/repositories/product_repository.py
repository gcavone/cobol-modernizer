from sqlalchemy.orm import Session
from typing import Optional, List
from models.product import Product
from repositories.base_repository import BaseRepository


class ProductRepository(BaseRepository):
    """Repository for managing Product entities.
    
    Provides specialized query methods for products beyond the base CRUD operations.
    """

    def __init__(self, session: Session) -> None:
        """Initialize ProductRepository with database session.
        
        Args:
            session: SQLAlchemy database session.
        """
        super().__init__(session, Product)

    def get_by_code(self, code: str) -> Optional[Product]:
        """Retrieve a product by its 8-digit code.
        
        Args:
            code: The product code (e.g., "00000001").
        
        Returns:
            The Product instance if found, None otherwise.
        """
        return self.session.query(Product).filter(
            Product.code == code
        ).first()

    def get_all_sorted_by_name(self) -> List[Product]:
        """Retrieve all products sorted alphabetically by name.
        
        Returns:
            List of all Product instances ordered by name.
        """
        return self.session.query(Product).order_by(Product.name).all()

    def search_by_name(self, name: str) -> List[Product]:
        """Search for products by name using case-insensitive pattern matching.
        
        Args:
            name: The search term (partial name match supported).
        
        Returns:
            List of Product instances matching the search term.
        """
        return self.session.query(Product).filter(
            Product.name.ilike(f"%{name}%")
        ).all()

FILE: repositories/admin_repository.py
ISTRUZIONE: Importa: sqlalchemy.orm (Session), typing (Optional), models.admin (Admin), repositories.base_repository (BaseRepository). Crea classe AdminRepository(BaseRepository) con __init__(self, session: Session) che chiama super().__init__(session, Admin). Implementa metodo: get_by_email(email: str) -> Optional[Admin].

from sqlalchemy.orm import Session
from typing import Optional
from models.admin import Admin
from repositories.base_repository import BaseRepository


class AdminRepository(BaseRepository):
    """Repository for managing Admin entities.
    
    Provides specialized query methods for admin users.
    """

    def __init__(self, session: Session) -> None:
        """Initialize AdminRepository with database session.
        
        Args:
            session: SQLAlchemy database session.
        """
        super().__init__(session, Admin)

    def get_by_email(self, email: str) -> Optional[Admin]:
        """Retrieve an admin by email address.
        
        Args:
            email: The admin email address.
        
        Returns:
            The Admin instance if found, None otherwise.
        """
        return self.session.query(Admin).filter(
            Admin.email == email
        ).first()

FILE: repositories/employee_repository.py
ISTRUZIONE: Importa: sqlalchemy.orm (Session), typing (Optional, List), models.employee (Employee), repositories.base_repository (BaseRepository). Crea classe EmployeeRepository(BaseRepository) con __init__(self, session: Session) che chiama super().__init__(session, Employee). Implementa metodi: get_by_employee_id(employee_id: str) -> Optional[Employee], get_all_sorted_by_name() -> List[Employee].

from sqlalchemy.orm import Session
from typing import Optional, List
from models.employee import Employee
from repositories.base_repository import BaseRepository


class EmployeeRepository(BaseRepository):
    """Repository for managing Employee entities.
    
    Provides specialized query methods for employees.
    """

    def __init__(self, session: Session) -> None:
        """Initialize EmployeeRepository with database session.
        
        Args:
            session: SQLAlchemy database session.
        """
        super().__init__(session, Employee)

    def get_by_employee_id(self, employee_id: str) -> Optional[Employee]:
        """Retrieve an employee by their employee ID code.
        
        Args:
            employee_id: The unique employee ID code.
        
        Returns:
            The Employee instance if found, None otherwise.
        """
        return self.session.query(Employee).filter(
            Employee.employee_id == employee_id
        ).first()

    def get_all_sorted_by_name(self) -> List[Employee]:
        """Retrieve all employees sorted alphabetically by name.
        
        Returns:
            List of all Employee instances ordered by name.
        """
        return self.session.query(Employee).order_by(Employee.name).all()

FILE: repositories/order_repository.py
ISTRUZIONE: Importa: sqlalchemy.orm (Session), typing (Optional, List), models.order (Order), repositories.base_repository (BaseRepository). Crea classe OrderRepository(BaseRepository) con __init__(self, session: Session) che chiama super().__init__(session, Order). Implementa metodi: get_by_order_number(order_number: str) -> Optional[Order], get_all_sorted_by_date() -> List[Order].

from sqlalchemy.orm import Session
from typing import Optional, List
from models.order import Order
from repositories.base_repository import BaseRepository


class OrderRepository(BaseRepository):
    """Repository for managing Order entities.
    
    Provides specialized query methods for customer orders.
    """

    def __init__(self, session: Session) -> None:
        """Initialize OrderRepository with database session.
        
        Args:
            session: SQLAlchemy database session.
        """
        super().__init__(session, Order)

    def get_by_order_number(self, order_number: str) -> Optional[Order]:
        """Retrieve an order by its order number.
        
        Args:
            order_number: The unique order number.
        
        Returns:
            The Order instance if found, None otherwise.
        """
        return self.session.query(Order).filter(
            Order.order_number == order_number
        ).first()

    def get_all_sorted_by_date(self) -> List[Order]:
        """Retrieve all orders sorted by creation date (newest first).
        
        Returns:
            List of all Order instances ordered by created_at descending.
        """
        return self.session.query(Order).order_by(
            Order.created_at.desc()
        ).all()

FILE: repositories/order_item_repository.py
ISTRUZIONE: Importa: sqlalchemy.orm (Session), typing (List), models.order_item (OrderItem), repositories.base_repository (BaseRepository). Crea classe OrderItemRepository(BaseRepository) con __init__(self, session: Session) che chiama super().__init__(session, OrderItem). Implementa metodo: get_by_order_id(order_id: int) -> List[OrderItem].

from sqlalchemy.orm import Session
from typing import List
from models.order_item import OrderItem
from repositories.base_repository import BaseRepository


class OrderItemRepository(BaseRepository):
    """Repository for managing OrderItem entities.
    
    Provides specialized query methods for order line items.
    """

    def __init__(self, session: Session) -> None:
        """Initialize OrderItemRepository with database session.
        
        Args:
            session: SQLAlchemy database session.
        """
        super().__init__(session, OrderItem)

    def get_by_order_id(self, order_id: int) -> List[OrderItem]:
        """Retrieve all items for a specific order.
        
        Args:
            order_id: The order ID.
        
        Returns:
            List of OrderItem instances for the given order.
        """
        return self.session.query(OrderItem).filter(
            OrderItem.order_id == order_id
        ).all()

FILE: repositories/salary_repository.py
ISTRUZIONE: Importa: sqlalchemy.orm (Session), typing (List), models.salary_record (SalaryRecord), repositories.base_repository (BaseRepository). Crea classe SalaryRepository(BaseRepository) con __init__(self, session: Session) che chiama super().__init__(session, SalaryRecord). Implementa metodo: get_by_employee_id(employee_id: int) -> List[SalaryRecord].

from sqlalchemy.orm import Session
from typing import List
from models.salary_record import SalaryRecord
from repositories.base_repository import BaseRepository


class SalaryRepository(BaseRepository):
    """Repository for managing SalaryRecord entities.
    
    Provides specialized query methods for salary calculations.
    """

    def __init__(self, session: Session) -> None:
        """Initialize SalaryRepository with database session.
        
        Args:
            session: SQLAlchemy database session.
        """
        super().__init__(session, SalaryRecord)

    def get_by_employee_id(self, employee_id: int) -> List[SalaryRecord]:
        """Retrieve all salary records for a specific employee.
        
        Args:
            employee_id: The employee ID.
        
        Returns:
            List of SalaryRecord instances for the given employee.
        """
        return self.session.query(SalaryRecord).filter(
            SalaryRecord.employee_id == employee_id
        ).all()

FILE: repositories/profit_repository.py
ISTRUZIONE: Importa: sqlalchemy.orm (Session), models.profit_record (ProfitRecord), repositories.base_repository (BaseRepository). Crea classe ProfitRepository(BaseRepository) con __init__(self, session: Session) che chiama super().__init__(session, ProfitRecord).

from sqlalchemy.orm import Session
from models.profit_record import ProfitRecord
from repositories.base_repository import BaseRepository


class ProfitRepository(BaseRepository):
    """Repository for managing ProfitRecord entities.
    
    Provides CRUD operations for profit calculations.
    """

    def __init__(self, session: Session) -> None:
        """Initialize ProfitRepository with database session.
        
        Args:
            session: SQLAlchemy database session.
        """
        super().__init__(session, ProfitRecord)

FILE: repositories/activity_log_repository.py
ISTRUZIONE: Importa: sqlalchemy.orm (Session), typing (List), models.activity_log (ActivityLog), repositories.base_repository (BaseRepository). Crea classe ActivityLogRepository(BaseRepository) con __init__(self, session: Session) che chiama super().__init__(session, ActivityLog). Implementa metodo: get_by_admin_id(admin_id: int) -> List[ActivityLog].

from sqlalchemy.orm import Session
from typing import List
from models.activity_log import ActivityLog
from repositories.base_repository import BaseRepository


class ActivityLogRepository(BaseRepository):
    """Repository for managing ActivityLog entities.
    
    Provides specialized query methods for activity logs.
    """

    def __init__(self, session: Session) -> None:
        """Initialize ActivityLogRepository with database session.
        
        Args:
            session: SQLAlchemy database session.
        """
        super().__init__(session, ActivityLog)

    def get_by_admin_id(self, admin_id: int) -> List[ActivityLog]:
        """Retrieve all activity logs for a specific admin.
        
        Args:
            admin_id: The admin ID.
        
        Returns:
            List of ActivityLog instances for the given admin.
        """
        return self.session.query(ActivityLog).filter(
            ActivityLog.admin_id == admin_id
        ).all()

FILE: services/__init__.py
ISTRUZIONE: File vuoto o con import dei servizi. Genera versione con import.

from services.auth_service import AuthService
from services.product_service import ProductService
from services.employee_service import EmployeeService
from services.order_service import OrderService
from services.profit_service import ProfitService
from services.activity_service import ActivityService

__all__ = [
    "AuthService",
    "ProductService",
    "EmployeeService",
    "OrderService",
    "ProfitService",
    "ActivityService",
]

FILE: services/auth_service.py
ISTRUZIONE: Importa: bcrypt, datetime (datetime), logging, repositories.admin_repository (AdminRepository). Crea classe AuthService con __init__(self, admin_repo: AdminRepository). Implementa metodi: authenticate(email: str, password: str) -> Admin (valida email/password con bcrypt, aggiorna last_login, solleva ValueError se fallisce), hash_password(password: str) -> str (genera hash bcrypt, solleva ValueError se password < 6 caratteri), create_admin(email: str, password: str) -> dict (crea nuovo admin, valida email unica, ritorna dict con id e email).

import bcrypt
import logging
from datetime import datetime
from repositories.admin_repository import AdminRepository
from models.admin import Admin


class AuthService:
    """Service for authentication and password management.
    
    Handles admin authentication, password hashing with bcrypt,
    and admin account creation.
    """

    def __init__(self, admin_repo: AdminRepository) -> None:
        """Initialize AuthService with admin repository.
        
        Args:
            admin_repo: Repository for admin data access.
        """
        self.admin_repo: AdminRepository = admin_repo
        self.logger: logging.Logger = logging.getLogger(__name__)

    def authenticate(self, email: str, password: str) -> Admin:
        """Authenticate an admin with email and password.
        
        Validates credentials against bcrypt hash stored in database
        and updates last_login timestamp on successful authentication.
        
        Args:
            email: Admin email address.
            password: Admin password (plaintext).
        
        Returns:
            Admin instance if authentication successful.
        
        Raises:
            ValueError: If email/password invalid or account inactive.
        """
        # Validate input
        if not email or not password:
            self.logger.warning("Authentication attempt with missing credentials")
            raise ValueError("Email and password are required")

        # Retrieve admin from database
        admin: Admin | None = self.admin_repo.get_by_email(email)
        if not admin:
            self.logger.warning(f"Authentication failed: email not found - {email}")
            raise ValueError("Invalid email or password")

        if not admin.is_active:
            self.logger.warning(f"Authentication failed: account inactive - {email}")
            raise ValueError("Account is inactive")

        # Verify password with bcrypt
        try:
            if not bcrypt.checkpw(password.encode(), admin.password_hash.encode()):
                self.logger.warning(f"Authentication failed: invalid password - {email}")
                raise ValueError("Invalid email or password")
        except Exception as e:
            self.logger.error(f"Authentication error: {str(e)}")
            raise ValueError(f"Authentication error: {str(e)}")

        # Update last login
        self.admin_repo.update(admin.id, last_login=datetime.utcnow())
        self.logger.info(f"Admin authenticated successfully: {email}")

        return admin

    @staticmethod
    def hash_password(password: str) -> str:
        """Generate bcrypt hash of a password.
        
        Args:
            password: Plaintext password to hash.
        
        Returns:
            Bcrypt hash string.
        
        Raises:
            ValueError: If password is too short (< 6 characters).
        """
        if not password or len(password) < 6:
            raise ValueError("Password must be at least 6 characters long")

        salt: bytes = bcrypt.gensalt(rounds=12)
        return bcrypt.hashpw(password.encode(), salt).decode()

    def create_admin(self, email: str, password: str) -> dict:
        """Create a new admin account with hashed password.
        
        Args:
            email: Admin email address (must be unique).
            password: Admin password (will be hashed).
        
        Returns:
            Dictionary with id and email of created admin.
        
        Raises:
            ValueError: If email invalid, already exists, or password too short.
        """
        # Validate email format
        if not email or "@" not in email:
            raise ValueError("Invalid email format")

        # Check email uniqueness
        if self.admin_repo.get_by_email(email):
            self.logger.warning(f"Admin creation failed: email already exists - {email}")
            raise ValueError("Email already exists")

        # Hash password
        password_hash: str = self.hash_password(password)

        # Create admin
        admin: Admin = self.admin_repo.create(
            email=email,
            password_hash=password_hash,
            is_active=True
        )

        self.logger.info(f"New admin created: {email}")

        return {"id": admin.id, "email": admin.email}

FILE: services/product_service.py
ISTRUZIONE: Importa: logging, decimal (Decimal), typing (List, Optional), repositories.product_repository (ProductRepository), services.activity_service (ActivityService). Crea classe ProductService con __init__(self, product_repo: ProductRepository, activity_service: ActivityService). Implementa metodi: create_product(code: str, name: str, unit: str, price: float, admin_id: int) -> Product (valida code 8 cifre, name non vuoto, price > 0, solleva ValueError se code duplicato, registra attività), get_product_by_id(product_id: int) -> Product (solleva ValueError se non trovato), get_product_by_code(code: str) -> Product (solleva ValueError se non trovato), get_all_products() -> List[Product], update_product(product_id: int, **kwargs) -> Product (valida dati, registra attività), delete_product(product_id: int, admin_id: int) -> bool (registra attività).

import logging
from decimal import Decimal
from typing import List, Optional
from repositories.product_repository import ProductRepository
from services.activity_service import ActivityService
from models.product import Product


class ProductService:
    """Service for managing product inventory.
    
    Handles CRUD operations for products with validation and activity logging.
    """

    def __init__(self, product_repo: ProductRepository, 
                 activity_service: ActivityService) -> None:
        """Initialize ProductService with repositories and services.
        
        Args:
            product_repo: Repository for product data access.
            activity_service: Service for logging activities.
        """
        self.product_repo: ProductRepository = product_repo
        self.activity_service: ActivityService = activity_service
        self.logger: logging.Logger = logging.getLogger(__name__)

    def create_product(self, code: str, name: str, unit: str, 
                      price: float, admin_id: int) -> Product:
        """Create a new product.
        
        Args:
            code: 8-digit product code (must be unique).
            name: Product name.
            unit: Unit of measurement (e.g., "155g", "1L").
            price: Unit price (must be > 0).
            admin_id: ID of admin creating the product.
        
        Returns:
            Created Product instance.
        
        Raises:
            ValueError: If validation fails or code already exists.
        """
        # Validate code format (8 digits)
        if not code or len(code) != 8 or not code.isdigit():
            raise ValueError("Product code must be exactly 8 digits")

        # Validate name
        if not name or len(name) < 2:
            raise ValueError("Product name must be at least 2 characters")

        # Validate unit
        if not unit or len(unit) < 1:
            raise ValueError("Unit of measurement is required")

        # Validate price
        try:
            price_decimal: Decimal = Decimal(str(price))
        except (ValueError, TypeError):
            raise ValueError("Price must be a valid number")

        if price_decimal <= 0:
            raise ValueError("Price must be greater than 0")

        # Check code uniqueness
        if self.product_repo.get_by_code(code):
            self.logger.warning(f"Product creation failed: code already exists - {code}")
            raise ValueError(f"Product code {code} already exists")

        # Create product
        product: Product = self.product_repo.create(
            code=code,
            name=name,
            unit=unit,
            price=float(price_decimal)
        )

        # Log activity
        self.activity_service.log_action(
            action="CREATE",
            entity_type="PRODUCT",
            entity_id=product.id,
            admin_id=admin_id,
            details=f"Code: {code}, Name: {name}, Price: {price_decimal}"
        )

        self.logger.info(f"Product created: {code} - {name}")

        return product

    def get_product_by_id(self, product_id: int) -> Product:
        """Retrieve a product by ID.
        
        Args:
            product_id: The product ID.
        
        Returns:
            Product instance.
        
        Raises:
            ValueError: If product not found.
        """
        product: Optional[Product] = self.product_repo.get_by_id(product_id)
        if not product:
            raise ValueError(f"Product {product_id} not found")
        return product

    def get_product_by_code(self, code: str) -> Product:
        """Retrieve a product by code.
        
        Args:
            code: The 8-digit product code.
        
        Returns:
            Product instance.
        
        Raises:
            ValueError: If product not found.
        """
        product: Optional[Product] = self.product_repo.get_by_code(code)
        if not product:
            raise ValueError(f"Product code {code} not found")
        return product

    def get_all_products(self) -> List[Product]:
        """Retrieve all products sorted by name.
        
        Returns:
            List of all Product instances.
        """
        return self.product_repo.get_all_sorted_by_name()

    def search_products_by_name(self, name: str) -> List[Product]:
        """Search products by name (case-insensitive).
        
        Args:
            name: Search term (partial match supported).
        
        Returns:
            List of matching Product instances.
        """
        if not name or len(name) < 1:
            raise ValueError("Search term must not be empty")
        return self.product_repo.search_by_name(name)

    def update_product(self, product_id: int, admin_id: int, **kwargs) -> Product:
        """Update an existing product.
        
        Args:
            product_id: The product ID to update.
            admin_id: ID of admin performing the update.
            **kwargs: Fields to update (code, name, unit, price).
        
        Returns:
            Updated Product instance.
        
        Raises:
            ValueError: If product not found or validation fails.
        """
        # Verify product exists
        product: Product = self.get_product_by_id(product_id)

        # Validate fields if provided
        if "code" in kwargs:
            code: str = kwargs["code"]
            if len(code) != 8 or not code.isdigit():
                raise ValueError("Product code must be exactly 8 digits")
            # Check uniqueness (excluding current product)
            existing: Optional[Product] = self.product_repo.get_by_code(code)
            if existing and existing.id != product_id:
                raise ValueError(f"Product code {code} already exists")

        if "name" in kwargs:
            name: str = kwargs["name"]
            if not name or len(name) < 2:
                raise ValueError("Product name must be at least 2 characters")

        if "price" in kwargs:
            try:
                price_decimal: Decimal = Decimal(str(kwargs["price"]))
            except (ValueError, TypeError):
                raise ValueError("Price must be a valid number")
            if price_decimal <= 0:
                raise ValueError("Price must be greater than 0")
            kwargs["price"] = float(price_decimal)

        # Update product
        updated_product: Optional[Product] = self.product_repo.update(product_id, **kwargs)

        # Log activity
        self.activity_service.log_action(
            action="UPDATE",
            entity_type="PRODUCT",
            entity_id=product_id,
            admin_id=admin_id,
            details=f"Updated fields: {', '.join(kwargs.keys())}"
        )

        self.logger.info(f"Product updated: {product_id}")

        return updated_product

    def delete_product(self, product_id: int, admin_id: int) -> bool:
        """Delete a product.
        
        Args:
            product_id: The product ID to delete.
            admin_id: ID of admin performing the deletion.
        
        Returns:
            True if deletion successful.
        
        Raises:
            ValueError: If product not found.
        """
        # Verify product exists
        product: Product = self.get_product_by_id(product_id)

        # Delete product
        success: bool = self.product_repo.delete(product_id)

        if success:
            # Log activity
            self.activity_service.log_action(
                action="DELETE",
                entity_type="PRODUCT",
                entity_id=product_id,
                admin_id=admin_id,
                details=f"Code: {product.code}, Name: {product.name}"
            )

            self.logger.info(f"Product deleted: {product_id}")

        return success

FILE: services/employee_service.py
ISTRUZIONE: Importa: logging, decimal (Decimal), repositories.employee_repository (EmployeeRepository), repositories.salary_repository (SalaryRepository), services.activity_service (ActivityService). Crea classe EmployeeService con __init__(self, employee_repo: EmployeeRepository, salary_repo: SalaryRepository, activity_service: ActivityService). Implementa metodi: calculate_salary(employee_id: int, hours_worked: float, admin_id: int) -> SalaryRecord (valida ore > 0 e <= 24, calcola SALARY = HOURLY_RATE * HOURS_WORKED, salva record, registra attività), get_employee_by_id(employee_id: int) -> Employee (solleva ValueError se non trovato), list_all_employees() -> List[Employee], create_employee(name: str, employee_id: str, hourly_rate: float = 500.0) -> Employee (valida dati, solleva ValueError se employee_id duplicato).

import logging
from decimal import Decimal
from typing import List, Optional
from repositories.employee_repository import EmployeeRepository
from repositories.salary_repository import SalaryRepository
from services.activity_service import ActivityService
from models.employee import Employee
from models.salary_record import SalaryRecord


class EmployeeService:
    """Service for managing employees and salary calculations.
    
    Handles employee CRUD operations and salary calculations
    following the rule: SALARY = HOURLY_RATE × HOURS_WORKED
    """

    def __init__(self, employee_repo: EmployeeRepository,
                 salary_repo: SalaryRepository,
                 activity_service: ActivityService) -> None:
        """Initialize EmployeeService with repositories and services.
        
        Args:
            employee_repo: Repository for employee data access.
            salary_repo: Repository for salary record data access.
            activity_service: Service for logging activities.
        """
        self.employee_repo: EmployeeRepository = employee_repo
        self.salary_repo: SalaryRepository = salary_repo
        self.activity_service: ActivityService = activity_service
        self.logger: logging.Logger = logging.getLogger(__name__)

    def calculate_salary(self, employee_id: int, hours_worked: float, 
                        admin_id: int) -> SalaryRecord:
        """Calculate and record employee salary.
        
        Implements business rule: SALARY = HOURLY_RATE × HOURS_WORKED
        
        Args:
            employee_id: The employee ID.
            hours_worked: Number of hours worked (must be > 0 and <= 24).
            admin_id: ID of admin performing the calculation.
        
        Returns:
            SalaryRecord with calculated salary.
        
        Raises:
            ValueError: If employee not found or hours invalid.
        """
        # Validate and convert hours_worked
        try:
            hours_decimal: Decimal = Decimal(str(hours_worked))
        except (ValueError, TypeError):
            raise ValueError("Hours worked must be a valid number")

        if hours_decimal <= 0:
            raise ValueError("Hours worked must be positive")

        if hours_decimal > 24:
            raise ValueError("Hours worked cannot exceed 24 per day")

        # Retrieve employee
        employee: Employee = self.get_employee_by_id(employee_id)

        # Calculate salary: SALARY = HOURLY_RATE × HOURS_WORKED
        hourly_rate: Decimal = Decimal(str(employee.hourly_rate))
        total_salary: Decimal = hourly_rate * hours_decimal

        # Create salary record
        salary_record: SalaryRecord = self.salary_repo.create(
            employee_id=employee_id,
            hours_worked=float(hours_decimal),
            hourly_rate=float(hourly_rate),
            total_salary=float(total_salary)
        )

        # Log activity
        self.activity_service.log_action(
            action="SALARY_CALCULATED",
            entity_type="EMPLOYEE",
            entity_id=employee_id,
            admin_id=admin_id,
            details=f"Hours: {hours_decimal}, Rate: {hourly_rate}, Salary: {total_salary}"
        )

        self.logger.info(
            f"Salary calculated for employee {employee_id}: "
            f"{hours_decimal}h × {hourly_rate} = {total_salary}"
        )

        return salary_record

    def get_employee_by_id(self, employee_id: int) -> Employee:
        """Retrieve an employee by ID.
        
        Args:
            employee_id: The employee ID.
        
        Returns:
            Employee instance.
        
        Raises:
            ValueError: If employee not found.
        """
        employee: Optional[Employee] = self.employee_repo.get_by_id(employee_id)
        if not employee:
            raise ValueError(f"Employee {employee_id} not found")
        return employee

    def get_employee_by_employee_id(self, employee_id: str) -> Employee:
        """Retrieve an employee by employee ID code.
        
        Args:
            employee_id: The employee ID code.
        
        Returns:
            Employee instance.
        
        Raises:
            ValueError: If employee not found.
        """
        employee: Optional[Employee] = self.employee_repo.get_by_employee_id(employee_id)
        if not employee:
            raise ValueError(f"Employee ID {employee_id} not found")
        return employee

    def list_all_employees(self) -> List[Employee]:
        """Retrieve all employees sorted by name.
        
        Returns:
            List of all Employee instances.
        """
        return self.employee_repo.get_all_sorted_by_name()

    def create_employee(self, name: str, employee_id: str, 
                       hourly_rate: float = 500.0) -> Employee:
        """Create a new employee.
        
        Args:
            name: Employee full name.
            employee_id: Unique employee ID code.
            hourly_rate: Hourly wage rate (default 500.00).
        
        Returns:
            Created Employee instance.
        
        Raises:
            ValueError: If validation fails or employee_id already exists.
        """
        # Validate name
        if not name or len(name) < 2:
            raise ValueError("Employee name must be at least 2 characters")

        # Validate employee_id
        if not employee_id or len(employee_id) < 2:
            raise ValueError("Employee ID must be at least 2 characters")

        # Check employee_id uniqueness
        if self.employee_repo.get_by_employee_id(employee_id):
            self.logger.warning(f"Employee creation failed: ID already exists - {employee_id}")
            raise ValueError(f"Employee ID {employee_id} already exists")

        # Validate hourly_rate
        try:
            rate_decimal: Decimal = Decimal(str(hourly_rate))
        except (ValueError, TypeError):
            raise ValueError("Hourly rate must be a valid number")

        if rate_decimal <= 0:
            raise ValueError("Hourly rate must be positive")

        # Create employee
        employee: Employee = self.employee_repo.create(
            name=name,
            employee_id=employee_id,
            hourly_rate=float(rate_decimal)
        )

        self.logger.info(f"Employee created: {employee_id} - {name}")

        return employee

    def update_employee(self, employee_id: int, **kwargs) -> Employee:
        """Update an existing employee.
        
        Args:
            employee_id: The employee ID to update.
            **kwargs: Fields to update (name, hourly_rate).
        
        Returns:
            Updated Employee instance.
        
        Raises:
            ValueError: If employee not found or validation fails.
        """
        # Verify employee exists
        employee: Employee = self.get_employee_by_id(employee_id)

        # Validate fields if provided
        if "name" in kwargs:
            name: str = kwargs["name"]
            if not name or len(name) < 2:
                raise ValueError("Employee name must be at least 2 characters")

        if "hourly_rate" in kwargs:
            try:
                rate_decimal: Decimal = Decimal(str(kwargs["hourly_rate"]))
            except (ValueError, TypeError):
                raise ValueError("Hourly rate must be a valid number")
            if rate_decimal <= 0:
                raise ValueError("Hourly rate must be positive")
            kwargs["hourly_rate"] = float(rate_decimal)

        # Update employee
        updated_employee: Optional[Employee] = self.employee_repo.update(
            employee_id, **kwargs
        )

        self.logger.info(f"Employee updated: {employee_id}")

        return updated_employee

FILE: services/order_service.py
ISTRUZIONE: Importa: logging, decimal (Decimal), datetime (datetime), typing (List, Optional), dataclasses (dataclass), repositories.order_repository (OrderRepository), repositories.order_item_repository (OrderItemRepository), repositories.product_repository (ProductRepository), services.activity_service (ActivityService). Crea dataclass OrderItemData con product_id: int, quantity: int, unit_price: Decimal. Crea classe OrderService con __init__(self, order_repo, order_item_repo, product_repo, activity_service). Implementa metodi: create_order(items: List[OrderItemData], payment_amount: Decimal, admin_id: int = None) -> dict (valida items e pagamento, calcola totale, salva Order e OrderItems, calcola CHANGE = PAYMENT - TOTAL, registra attività, ritorna dict con order, items, totals), calculate_change(total_amount: Decimal, payment_amount: Decimal) -> Decimal (calcola resto, solleva ValueError se payment < total), get_order_receipt(order_id: int) -> dict (recupera ricevuta con ordine e dettagli).

import logging
from decimal import Decimal
from datetime import datetime
from typing import List, Optional
from dataclasses import dataclass
from repositories.order_repository import OrderRepository
from repositories.order_item_repository import OrderItemRepository
from repositories.product_repository import ProductRepository
from services.activity_service import ActivityService
from models.order import Order
from models.order_item import OrderItem


@dataclass
class OrderItemData:
    """Data class for order item input.
    
    Attributes:
        product_id: ID of the product.
        quantity: Number of units ordered.
        unit_price: Price per unit.
    """
    product_id: int
    quantity: int
    unit_price: Decimal


class OrderService:
    """Service for managing customer orders.
    
    Handles order creation, item management, and implements
    the business rule: CHANGE = PAYMENT - TOTAL
    """

    def __init__(self, order_repo: OrderRepository,
                 order_item_repo: OrderItemRepository,
                 product_repo: ProductRepository,
                 activity_service: ActivityService) -> None:
        """Initialize OrderService with repositories and services.
        
        Args:
            order_repo: Repository for order data access.
            order_item_repo: Repository for order item data access.
            product_repo: Repository for product data access.
            activity_service: Service for logging activities.
        """
        self.order_repo: OrderRepository = order_repo
        self.order_item_repo: OrderItemRepository = order_item_repo
        self.product_repo: ProductRepository = product_repo
        self.activity_service: ActivityService = activity_service
        self.logger: logging.Logger = logging.getLogger(__name__)

    def create_order(self, items: List[OrderItemData], 
                    payment_amount: Decimal, admin_id: int | None = None) -> dict:
        """Create a new customer order.
        
        Implements order creation flow:
        1. Validate items and payment
        2. Calculate total amount
        3. Save order and items to database
        4. Calculate change: CHANGE = PAYMENT - TOTAL
        5. Log activity
        
        Args:
            items: List of OrderItemData (product_id, quantity, unit_price).
            payment_amount: Amount paid by customer.
            admin_id: ID of admin creating order (optional).
        
        Returns:
            Dictionary with order, items, total_amount, payment_amount, change_amount.
        
        Raises:
            ValueError: If items invalid, payment insufficient, or product not found.
        """
        # Validate items list
        if not items or len(items) == 0:
            raise ValueError("Order must contain at least one item")

        if len(items) > 100:
            raise ValueError("Order cannot contain more than 100 items")

        # Validate payment amount
        try:
            payment_decimal: Decimal = Decimal(str(payment_amount))
        except (ValueError, TypeError):
            raise ValueError("Payment amount must be a valid number")

        if payment_decimal <= 0:
            raise ValueError("Payment amount must be positive")

        # Calculate total and validate items
        total_amount: Decimal = Decimal('0')
        validated_items: List[tuple] = []

        for item in items:
            # Validate quantity
            if item.quantity <= 0:
                raise ValueError("Quantity must be positive")

            # Validate unit price
            try:
                unit_price: Decimal = Decimal(str(item.unit_price))
            except (ValueError, TypeError):
                raise ValueError("Unit price must be a valid number")

            if unit_price <= 0:
                raise ValueError("Unit price must be positive")

            # Verify product exists
            product: Optional[Order] = self.product_repo.get_by_id(item.product_id)
            if not product:
                raise ValueError(f"Product {item.product_id} not found")

            # Calculate subtotal
            subtotal: Decimal = Decimal(item.quantity) * unit_price
            total_amount += subtotal

            validated_items.append((item, unit_price, subtotal))

        # Validate payment >= total
        if payment_decimal < total_amount:
            raise ValueError(
                f"Insufficient payment. Total: {total_amount}, "
                f"Paid: {payment_decimal}"
            )

        # Calculate change: CHANGE = PAYMENT - TOTAL
        change_amount: Decimal = payment_decimal - total_amount

        # Create order
        order: Order = self.order_repo.create(
            order_number=self._generate_order_number(),
            total_amount=float(total_amount),
            payment_amount=float(payment_decimal),
            change_amount=float(change_amount)
        )

        # Create order items
        order_items: List[OrderItem] = []
        for item, unit_price, subtotal in validated_items:
            order_item: OrderItem = self.order_item_repo.create(
                order_id=order.id,
                product_id=item.product_id,
                quantity=item.quantity,
                unit_price=float(unit_price),
                subtotal=float(subtotal)
            )
            order_items.append(order_item)

        # Log activity
        self.activity_service.log_action(
            action="ORDER_CREATED",
            entity_type="ORDER",
            entity_id=order.id,
            admin_id=admin_id,
            details=f"Total: {total_amount}, Items: {len(items)}, Change: {change_amount}"
        )

        self.logger.info(
            f"Order created: {order.order_number} - "
            f"Total: {total_amount}, Change: {change_amount}"
        )

        return {
            "order": order,
            "items": order_items,
            "total_amount": float(total_amount),
            "payment_amount": float(payment_decimal),
            "change_amount": float(change_amount)
        }

    def calculate_change(self, total_amount: Decimal, 
                        payment_amount: Decimal) -> Decimal:
        """Calculate change amount.
        
        Implements business rule: CHANGE = PAYMENT - TOTAL
        
        Args:
            total_amount: Total order amount.
            payment_amount: Amount paid by customer.
        
        Returns:
            Change amount.
        
        Raises:
            ValueError: If payment is insufficient.
        """
        try:
            total: Decimal = Decimal(str(total_amount))
            payment: Decimal = Decimal(str(payment_amount))
        except (ValueError, TypeError):
            raise ValueError("Amounts must be valid numbers")

        if payment < total:
            raise ValueError(
                f"Insufficient payment. Total: {total}, Paid: {payment}"
            )

        return payment - total

    def get_order_receipt(self, order_id: int) -> dict:
        """Retrieve order receipt with details.
        
        Args:
            order_id: The order ID.
        
        Returns:
            Dictionary with order details and items.
        
        Raises:
            ValueError: If order not found.
        """
        order: Optional[Order] = self.order_repo.get_by_id(order_id)
        if not order:
            raise ValueError(f"Order {order_id} not found")

        items: List[OrderItem] = self.order_item_repo.get_by_order_id(order_id)

        return {
            "order_number": order.order_number,
            "created_at": order.created_at,
            "items": items,
            "total_amount": order.total_amount,
            "payment_amount": order.payment_amount,
            "change_amount": order.change_amount
        }

    def get_order_by_id(self, order_id: int) -> Order:
        """Retrieve an order by ID.
        
        Args:
            order_id: The order ID.
        
        Returns:
            Order instance.
        
        Raises:
            ValueError: If order not found.
        """
        order: Optional[Order] = self.order_repo.get_by_id(order_id)
        if not order:
            raise ValueError(f"Order {order_id} not found")
        return order

    def list_all_orders(self) -> List[Order]:
        """Retrieve all orders sorted by date (newest first).
        
        Returns:
            List of all Order instances.
        """
        return self.order_repo.get_all_sorted_by_date()

    @staticmethod
    def _generate_order_number() -> str:
        """Generate unique order number.
        
        Returns:
            Order number string (format: ORD-YYYYMMDDHHmmss).
        """
        return f"ORD-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}"

FILE: services/profit_service.py
ISTRUZIONE: Importa: logging, decimal (Decimal), repositories.profit_repository (ProfitRepository), services.activity_service (ActivityService). Crea classe ProfitService con __init__(self, profit_repo: ProfitRepository, activity_service: ActivityService). Implementa metodi: calculate_profit(cogs: Decimal, selling_price: Decimal, admin_id: int) -> ProfitRecord (valida cogs >= 0 e selling_price > 0, calcola PROFIT = SELLING_PRICE - COGS, salva record, registra attività), get_profit_by_id(profit_id: int) -> ProfitRecord (solleva ValueError se non trovato), list_all_profits() -> List[ProfitRecord].

import logging
from decimal import Decimal
from typing import List, Optional
from repositories.profit_repository import ProfitRepository
from services.activity_service import ActivityService
from models.profit_record import ProfitRecord


class ProfitService:
    """Service for managing profit calculations.
    
    Handles profit calculation and implements the business rule:
    PROFIT = SELLING_PRICE - COGS
    """

    def __init__(self, profit_repo: ProfitRepository,
                 activity_service: ActivityService) -> None:
        """Initialize ProfitService with repositories and services.
        
        Args:
            profit_repo: Repository for profit record data access.
            activity_service: Service for logging activities.
        """
        self.profit_repo: ProfitRepository = profit_repo
        self.activity_service: ActivityService = activity_service
        self.logger: logging.Logger = logging.getLogger(__name__)

    def calculate_profit(self, cogs: Decimal, selling_price: Decimal, 
                        admin_id: int) -> ProfitRecord:
        """Calculate and record profit.
        
        Implements business rule: PROFIT = SELLING_PRICE - COGS
        
        Args:
            cogs: Cost of goods sold (must be >= 0).
            selling_price: Selling price (must be > 0).
            admin_id: ID of admin performing the calculation.
        
        Returns:
            ProfitRecord with calculated profit.
        
        Raises:
            ValueError: If values invalid.
        """
        # Validate and convert COGS
        try:
            cogs_decimal: Decimal = Decimal(str(cogs))
        except (ValueError, TypeError):
            raise ValueError("COGS must be a valid number")

        if cogs_decimal < 0:
            raise ValueError("COGS cannot be negative")

        # Validate and convert selling price
        try:
            selling_price_decimal: Decimal = Decimal(str(selling_price))
        except (ValueError, TypeError):
            raise ValueError("Selling price must be a valid number")

        if selling_price_decimal <= 0:
            raise ValueError("Selling price must be positive")

        # Calculate profit: PROFIT = SELLING_PRICE - COGS
        profit: Decimal = selling_price_decimal - cogs_decimal

        # Create profit record
        profit_record: ProfitRecord = self.profit_repo.create(
            cogs=float(cogs_decimal),
            selling_price=float(selling_price_decimal),
            profit=float(profit)
        )

        # Log activity
        self.activity_service.log_action(
            action="PROFIT_CALCULATED",
            entity_type="PROFIT",
            entity_id=profit_record.id,
            admin_id=admin_id,
            details=f"COGS: {cogs_decimal}, Selling Price: {selling_price_decimal}, Profit: {profit}"
        )

        self.logger.info(
            f"Profit calculated: {selling_price_decimal} - {cogs_decimal} = {profit}"
        )

        return profit_record

    def get_profit_by_id(self, profit_id: int) -> ProfitRecord:
        """Retrieve a profit record by ID.
        
        Args:
            profit_id: The profit record ID.
        
        Returns:
            ProfitRecord instance.
        
        Raises:
            ValueError: If profit record not found.
        """
        profit: Optional[ProfitRecord] = self.profit_repo.get_by_id(profit_id)
        if not profit:
            raise ValueError(f"Profit record {profit_id} not found")
        return profit

    def list_all_profits(self) -> List[ProfitRecord]:
        """Retrieve all profit records.
        
        Returns:
            List of all ProfitRecord instances.
        """
        return self.profit_repo.get_all()

FILE: services/activity_service.py
ISTRUZIONE: Importa: logging, datetime (datetime), repositories.activity_log_repository (ActivityLogRepository). Crea classe ActivityService con __init__(self, activity_repo: ActivityLogRepository). Implementa metodo: log_action(action: str, entity_type: str, entity_id: int = None, admin_id: int = None, details: str = None) -> ActivityLog (salva nel database e registra nel log file).

import logging
from datetime import datetime
from repositories.activity_log_repository import ActivityLogRepository
from models.activity_log import ActivityLog


class ActivityService:
    """Service for logging system activities and administrative actions.
    
    Records all significant actions in both database and log file
    for audit trail and debugging purposes.
    """

    def __init__(self, activity_repo: ActivityLogRepository) -> None:
        """Initialize ActivityService with activity log repository.
        
        Args:
            activity_repo: Repository for activity log data access.
        """
        self.activity_repo: ActivityLogRepository = activity_repo
        self.logger: logging.Logger = logging.getLogger(__name__)

    def log_action(self, action: str, entity_type: str, entity_id: int | None = None,
                   admin_id: int | None = None, details: str | None = None) -> ActivityLog:
        """Log an activity to database and file.
        
        Records administrative actions and system events for audit trail.
        
        Args:
            action: Type of action (e.g., CREATE, UPDATE, DELETE, LOGIN).
            entity_type: Type of entity affected (e.g., PRODUCT, ORDER, EMPLOYEE).
            entity_id: ID of the entity affected (optional).
            admin_id: ID of admin who performed the action (optional).
            details: Additional details about the action (optional).
        
        Returns:
            ActivityLog instance.
        """
        # Validate action and entity_type
        if not action or len(action) < 1:
            raise ValueError("Action is required")

        if not entity_type or len(entity_type) < 1:
            raise ValueError("Entity type is required")

        # Create activity log record
        activity_log: ActivityLog = self.activity_repo.create(
            action=action,
            entity_type=entity_type,
            entity_id=entity_id,
            admin_id=admin_id,
            details=details
        )

        # Log to file
        log_message: str = (
            f"Action: {action} | Entity: {entity_type}:{entity_id} | "
            f"Admin: {admin_id} | Details: {details}"
        )
        self.logger.info(log_message)

        return activity_log

FILE: database/__init__.py
ISTRUZIONE: File vuoto o con import. Genera versione con import.

from database.connection import DatabaseConnection
from database.init_db import init_database

__all__ = [
    "DatabaseConnection",
    "init_database",
]

FILE: database/connection.py
ISTRUZIONE: Importa: sqlalchemy (create_engine), sqlalchemy.orm (sessionmaker, Session), config (Config). Crea classe DatabaseConnection con metodo statico get_session() -> Session che ritorna una sessione SQLAlchemy. Implementa __init__ che crea engine e session factory.

from sqlalchemy import create_engine, Engine
from sqlalchemy.orm import sessionmaker, Session
from config import Config


class DatabaseConnection:
    """Manages database connection and session creation.
    
    Provides a singleton-like interface for obtaining database sessions.
    """

    _engine: Engine | None = None
    _session_factory: sessionmaker | None = None

    @classmethod
    def initialize(cls) -> None:
        """Initialize database connection and session factory.
        
        Should be called once at application startup.
        """
        if cls._engine is None:
            cls._engine = create_engine(
                Config.DATABASE_URL,
                echo=False,
                pool_pre_ping=True
            )
            cls._session_factory = sessionmaker(bind=cls._engine)

    @classmethod
    def get_session(cls) -> Session:
        """Get a new database session.
        
        Returns:
            SQLAlchemy Session instance.
        
        Raises:
            RuntimeError: If database not initialized.
        """
        if cls._session_factory is None:
            raise RuntimeError("Database not initialized. Call initialize() first.")
        return cls._session_factory()

    @classmethod
    def get_engine(cls) -> Engine:
        """Get the database engine.
        
        Returns:
            SQLAlchemy Engine instance.
        
        Raises:
            RuntimeError: If database not initialized.
        """
        if cls._engine is None:
            raise RuntimeError("Database not initialized. Call initialize() first.")
        return cls._engine

    @classmethod
    def close_session(cls, session: Session) -> None:
        """Close a database session.
        
        Args:
            session: The session to close.
        """
        if session:
            session.close()

FILE: database/init_db.py
ISTRUZIONE: Importa: sqlalchemy.orm (sessionmaker), config (Config), database.connection (DatabaseConnection), models (Base, Product, Admin, Employee, Order, OrderItem, SalaryRecord, ProfitRecord, ActivityLog), repositories (ProductRepository, AdminRepository, EmployeeRepository), services (AuthService). Crea funzione init_database() che: 1) crea engine, 2) crea tutte le tabelle con Base.metadata.create_all(engine), 3) crea admin di default (robby@gmail.com con password hashata), 4) crea prodotti di esempio, 5) crea dipendenti di esempio. Crea main che chiama init_database().

from sqlalchemy.orm import sessionmaker
from config import Config
from database.connection import DatabaseConnection
from models.product import Product
from models.admin import Admin
from models.employee import Employee
from models.order import Order
from models.order_item import OrderItem
from models.salary_record import SalaryRecord
from models.profit_record import ProfitRecord
from models.activity_log import ActivityLog
from models.product import Base
from repositories.product_repository import ProductRepository
from repositories.admin_repository import AdminRepository
from repositories.employee_repository import EmployeeRepository
from services.auth_service import AuthService


def init_database() -> None:
    """Initialize database: create tables and seed default data.
    
    Creates all tables and populates with default admin, products, and employees.
    """
    # Initialize database connection
    DatabaseConnection.initialize()
    engine = DatabaseConnection.get_engine()

    # Create all tables
    Base.metadata.create_all(engine)
    print("✓ Database tables created successfully")

    # Create session
    Session = sessionmaker(bind=engine)
    session = Session()

    try:
        # Create default admin
        admin_repo = AdminRepository(session)
        default_email = "robby@gmail.com"

        if not admin_repo.get_by_email(default_email):
            password_hash = AuthService.hash_password("robby@123")
            admin_repo.create(
                email=default_email,
                password_hash=password_hash,
                is_active=True
            )
            print(f"✓ Default admin created: {default_email}")
        else:
            print(f"✓ Default admin already exists: {default_email}")

        # Create sample products
        product_repo = ProductRepository(session)
        sample_products = [
            {
                "code": "00000001",
                "name": "Canned Sardines",
                "unit": "155g",
                "price": 18.75
            },
            {
                "code": "00000002",
                "name": "Canned Sardines Spicy",
                "unit": "155g",
                "price": 18.75
            },
            {
                "code": "00000003",
                "name": "Condensed Milk",
                "unit": "300mL",
                "price": 53.00
            },
            {
                "code": "00000004",
                "name": "Evaporated Milk",
                "unit": "410mL",
                "price": 44.00
            },
            {
                "code": "00000005",
                "name": "Powdered Milk",
                "unit": "300g",
                "price": 96.25
            },
            {
                "code": "00000006",
                "name": "Cooking Oil",
                "unit": "1L",
                "price": 125.50
            },
            {
                "code": "00000007",
                "name": "Rice",
                "unit": "2kg",
                "price": 85.00
            },
            {
                "code": "00000008",
                "name": "Sugar",
                "unit": "1kg",
                "price": 45.00
            },
        ]

        created_count = 0
        for prod in sample_products:
            if not product_repo.get_by_code(prod["code"]):
                product_repo.create(**prod)
                created_count += 1

        print(f"✓ {created_count} sample products created")

        # Create sample employees
        employee_repo = EmployeeRepository(session)
        sample_employees = [
            {
                "name": "Juan Dela Cruz",
                "employee_id": "EMP001",
                "hourly_rate": 500.00
            },
            {
                "name": "Maria Santos",
                "employee_id": "EMP002",
                "hourly_rate": 500.00
            },
            {
                "name": "Pedro Reyes",
                "employee_id": "EMP003",
                "hourly_rate": 550.00
            },
            {
                "name": "Ana Garcia",
                "employee_id": "EMP004",
                "hourly_rate": 500.00
            },
        ]

        created_emp_count = 0
        for emp in sample_employees:
            if not employee_repo.get_by_employee_id(emp["employee_id"]):
                employee_repo.create(**emp)
                created_emp_count += 1

        print(f"✓ {created_emp_count} sample employees created")

        print("\n✓ Database initialization completed successfully!")

    except Exception as e:
        print(f"✗ Error during database initialization: {str(e)}")
        raise
    finally:
        session.close()


if __name__ == "__main__":
    init_database()

FILE: cli/__init__.py
ISTRUZIONE: File vuoto o con import. Genera versione con import.

from cli.main_menu import MainMenu
from cli.admin_menu import AdminMenu
from cli.buyer_menu import BuyerMenu
from cli.product_menu import ProductMenu
from cli.employee_menu import EmployeeMenu
from cli.profit_menu import ProfitMenu
from cli.order_menu import OrderMenu
from cli.ui_helpers import (
    clear_screen,
    print_header,
    ask_continue,
    print_table,
    format_currency,
    format_decimal,
)

__all__ = [
    "MainMenu",
    "AdminMenu",
    "BuyerMenu",
    "ProductMenu",
    "EmployeeMenu",
    "ProfitMenu",
    "OrderMenu",
    "clear_screen",
    "print_header",
    "ask_continue",
    "print_table",
    "format_currency",
    "format_decimal",
]

FILE: cli/ui_helpers.py
ISTRUZIONE: Importa: os, typing (List). Implementa funzioni: clear_screen() (pulisce schermo), print_header(title: str) (stampa intestazione con bordi), ask_continue(prompt: str = "Enter another? [Y/N]: ") -> bool (chiede se continuare, ritorna True se Y, False se N), print_table(headers: List[str], rows: List[List[str]]) (stampa tabella formattata), format_currency(value: float) -> str (formatta valore come valuta), format_decimal(value: float, decimals: int = 2) -> str (formatta numero decimale).

import os
from typing import List


def clear_screen() -> None:
    """Clear the terminal screen.
    
    Works on both Windows (cls) and Unix-like systems (clear).
    """
    os.system('cls' if os.name == 'nt' else 'clear')


def print_header(title: str) -> None:
    """Print a formatted header with borders.
    
    Args:
        title: The header title text.
    """
    width: int = 60
    print("=" * width)
    print(f"{title:^{width}}")
    print("=" * width)


def ask_continue(prompt: str = "Enter another? [Y/N]: ") -> bool:
    """Ask user if they want to continue an operation.
    
    Loops until valid input (Y or N) is received.
    
    Args:
        prompt: The prompt message to display.
    
    Returns:
        True if user enters Y, False if user enters N.
    """
    while True:
        answer: str = input(prompt).strip().upper()
        if answer in ['Y', 'YES']:
            return True
        elif answer in ['N', 'NO']:
            return False
        else:
            print("Invalid input. Please enter Y or N.")


def print_table(headers: List[str], rows: List[List[str]]) -> None:
    """Print a formatted table with headers and rows.
    
    Automatically calculates column widths based on content.
    
    Args:
        headers: List of column header strings.
        rows: List of rows, each row is a list of strings.
    """
    if not headers or not rows:
        print("No data to display.")
        return

    # Calculate column widths
    col_widths: List[int] = [
        max(len(h), max(len(str(r[i])) for r in rows) if rows else 0)
        for i, h in enumerate(headers)
    ]

    # Print header
    header_row: str = " | ".join(h.ljust(w) for h, w in zip(headers, col_widths))
    print(header_row)
    print("-" * len(header_row))

    # Print rows
    for row in rows:
        print(" | ".join(str(r).ljust(w) for r, w in zip(row, col_widths)))


def format_currency(value: float) -> str:
    """Format a value as currency (PHP).
    
    Args:
        value: The numeric value to format.
    
    Returns:
        Formatted currency string (e.g., "₱1,234.56").
    """
    return f"₱{value:,.2f}"


def format_decimal(value: float, decimals: int = 2) -> str:
    """Format a decimal number with specified precision.
    
    Args:
        value: The numeric value to format.
        decimals: Number of decimal places (default 2).
    
    Returns:
        Formatted decimal string.
    """
    return f"{value:.{decimals}f}"

FILE: cli/main_menu.py
ISTRUZIONE: Importa: logging, services (AuthService, ProductService), cli.admin_menu (AdminMenu), cli.buyer_menu (BuyerMenu), cli.ui_helpers (clear_screen, print_header). Crea classe MainMenu con __init__(self, auth_service: AuthService, product_service: ProductService). Implementa metodi: display() (mostra menu principale in loop), _admin_login() (richiede email/password, chiama auth_service.authenticate(), mostra AdminMenu se OK, mostra errore se fallisce).

import logging
from services.auth_service import AuthService
from services.product_service import ProductService
from cli.admin_menu import AdminMenu
from cli.buyer_menu import BuyerMenu
from cli.ui_helpers import clear_screen, print_header


class MainMenu:
    """Main menu for the supermarket management system.
    
    Provides entry point for administrators and buyers.
    """

    def __init__(self, auth_service: AuthService, 
                 product_service: ProductService) -> None:
        """Initialize MainMenu with required services.
        
        Args:
            auth_service: Service for authentication.
            product_service: Service for product management.
        """
        self.auth_service: AuthService = auth_service
        self.product_service: ProductService = product_service
        self.logger: logging.Logger = logging.getLogger(__name__)

    def display(self) -> None:
        """Display main menu and handle user selection.
        
        Loops until user chooses to exit.
        """
        while True:
            clear_screen()
            print_header("SUPERMARKET MANAGEMENT SYSTEM")

            print("\n1) Administrator")
            print("2) Buyer")
            print("3) Exit")

            choice: str = input("\nSelect option: ").strip()

            if choice == "1":
                self._admin_login()
            elif choice == "2":
                buyer_menu = BuyerMenu(self.product_service)
                buyer_menu.display()
            elif choice == "3":
                print("\nThank you for using the system. Goodbye!")
                self.logger.info("Application terminated by user")
                break
            else:
                print("\n❌ Invalid choice. Please select 1, 2, or 3.")
                input("Press Enter to continue...")

    def _admin_login(self) -> None:
        """Handle administrator login.
        
        Prompts for email and password, authenticates, and displays admin menu.
        """
        clear_screen()
        print_header("ADMINISTRATOR LOGIN")

        email: str = input("\nEmail: ").strip()
        password: str = input("Password: ").strip()

        try:
            admin = self.auth_service.authenticate(email, password)
            print(f"\n✓ Welcome, {admin.email}!")
            input("Press Enter to continue...")

            # Display admin menu
            admin_menu = AdminMenu(
                auth_service=self.auth_service,
                product_service=self.product_service,
                admin_id=admin.id
            )
            admin_menu.display()

        except ValueError as e:
            print(f"\n❌ Login failed: {str(e)}")
            self.logger.warning(f"Failed login attempt for email: {email}")
            input("Press Enter to continue...")

FILE: cli/admin_menu.py
ISTRUZIONE: Importa: logging, services (AuthService, ProductService, EmployeeService, OrderService, ProfitService), cli.product_menu (ProductMenu), cli.employee_menu (EmployeeMenu), cli.profit_menu (ProfitMenu), cli.order_menu (OrderMenu), cli.ui_helpers (clear_screen, print_header). Crea classe AdminMenu con __init__(self, auth_service, product_service, admin_id). Implementa metodo display() che mostra menu admin con opzioni: 1) Manage Products, 2) Manage Employees, 3) Calculate Profit, 4) View Orders, 5) Logout. Ogni opzione chiama il menu corrispondente.

import logging
from services.auth_service import AuthService
from services.product_service import ProductService
from services.employee_service import EmployeeService
from services.order_service import OrderService
from services.profit_service import ProfitService
from cli.product_menu import ProductMenu
from cli.employee_menu import EmployeeMenu
from cli.profit_menu import ProfitMenu
from cli.order_menu import OrderMenu
from cli.ui_helpers import clear_screen, print_header


class AdminMenu:
    """Administrator menu for system management.
    
    Provides access to product, employee, profit, and order management.
    """

    def __init__(self, auth_service: AuthService,
                 product_service: ProductService,
                 employee_service: EmployeeService | None = None,
                 order_service: OrderService | None = None,
                 profit_service: ProfitService | None = None,
                 admin_id: int | None = None) -> None:
        """Initialize AdminMenu with required services.
        
        Args:
            auth_service: Service for authentication.
            product_service: Service for product management.
            employee_service: Service for employee management (optional).
            order_service: Service for order management (optional).
            profit_service: Service for profit calculation (optional).
            admin_id: ID of logged-in administrator.
        """
        self.auth_service: AuthService = auth_service
        self.product_service: ProductService = product_service
        self.employee_service: EmployeeService | None = employee_service
        self.order_service: OrderService | None = order_service
        self.profit_service: ProfitService | None = profit_service
        self.admin_id: int | None = admin_id
        self.logger: logging.Logger = logging.getLogger(__name__)

    def display(self) -> None:
        """Display administrator menu and handle selections.
        
        Loops until user chooses to logout.
        """
        while True:
            clear_screen()
            print_header("ADMINISTRATOR MENU")

            print("\n1) Manage Products")
            print("2) Manage Employees")
            print("3) Calculate Profit")
            print("4) View Orders")
            print("5) Logout")

            choice: str = input("\nSelect option: ").strip()

            if choice == "1":
                product_menu = ProductMenu(self.product_service, self.admin_id)
                product_menu.display()
            elif choice == "2":
                if self.employee_service:
                    employee_menu = EmployeeMenu(self.employee_service, self.admin_id)
                    employee_menu.display()
                else:
                    print("\n❌ Employee service not available")
                    input("Press Enter to continue...")
            elif choice == "3":
                if self.profit_service:
                    profit_menu = ProfitMenu(self.profit_service, self.admin_id)
                    profit_menu.display()
                else:
                    print("\n❌ Profit service not available")
                    input("Press Enter to continue...")
            elif choice == "4":
                if self.order_service:
                    order_menu = OrderMenu(self.order_service)
                    order_menu.display()
                else:
                    print("\n❌ Order service not available")
                    input("Press Enter to continue...")
            elif choice == "5":
                print("\n✓ Logged out successfully")
                self.logger.info(f"Admin {self.admin_id} logged out")
                break
            else:
                print("\n❌ Invalid choice. Please select 1-5.")
                input("Press Enter to continue...")

FILE: cli/buyer_menu.py
ISTRUZIONE: Importa: logging, services (ProductService, OrderService), cli.order_menu (OrderMenu), cli.ui_helpers (clear_screen, print_header, print_table). Crea classe BuyerMenu con __init__(self, product_service: ProductService, order_service: OrderService = None). Implementa metodi: display() (mostra menu buyer con opzioni: 1) View Products, 2) Create Order, 3) Exit), view_products() (mostra lista prodotti in tabella), create_order() (guida utente attraverso creazione ordine).

import logging
from typing import List
from services.product_service import ProductService
from services.order_service import OrderService
from cli.ui_helpers import clear_screen, print_header, print_table, format_currency


class BuyerMenu:
    """Buyer menu for customer shopping.
    
    Provides product browsing and order creation functionality.
    """

    def __init__(self, product_service: ProductService,
                 order_service: OrderService | None = None) -> None:
        """Initialize BuyerMenu with required services.
        
        Args:
            product_service: Service for product management.
            order_service: Service for order management (optional).
        """
        self.product_service: ProductService = product_service
        self.order_service: OrderService | None = order_service
        self.logger: logging.Logger = logging.getLogger(__name__)

    def display(self) -> None:
        """Display buyer menu and handle selections.
        
        Loops until user chooses to exit.
        """
        while True:
            clear_screen()
            print_header("BUYER MENU")

            print("\n1) View Products")
            print("2) Create Order")
            print("3) Exit")

            choice: str = input("\nSelect option: ").strip()

            if choice == "1":
                self.view_products()
            elif choice == "2":
                if self.order_service:
                    self.create_order()
                else:
                    print("\n❌ Order service not available")
                    input("Press Enter to continue...")
            elif choice == "3":
                break
            else:
                print("\n❌ Invalid choice. Please select 1-3.")
                input("Press Enter to continue...")

    def view_products(self) -> None:
        """Display all available products in a formatted table."""
        clear_screen()
        print_header("AVAILABLE PRODUCTS")

        try:
            products = self.product_service.get_all_products()

            if not products:
                print("\nNo products available.")
                input("Press Enter to continue...")
                return

            headers: List[str] = ["Code", "Name", "Unit", "Price"]
            rows: List[List[str]] = [
                [
                    p.code,
                    p.name,
                    p.unit,
                    format_currency(float(p.price))
                ]
                for p in products
            ]

            print()
            print_table(headers, rows)
            input("\nPress Enter to continue...")

        except Exception as e:
            print(f"\n❌ Error loading products: {str(e)}")
            self.logger.error(f"Error in view_products: {str(e)}")
            input("Press Enter to continue...")

    def create_order(self) -> None:
        """Guide user through order creation process."""
        clear_screen()
        print_header("CREATE ORDER")

        try:
            # Display available products
            products = self.product_service.get_all_products()
            if not products:
                print("\nNo products available for ordering.")
                input("Press Enter to continue...")
                return

            print("\nAvailable Products:")
            for p in products:
                print(f"  {p.code} - {p.name} ({p.unit}) - {format_currency(float(p.price))}")

            # Get number of items
            try:
                num_items: int = int(input("\nHow many items to order? "))
                if num_items <= 0 or num_items > 100:
                    print("❌ Number of items must be between 1 and 100")
                    input("Press Enter to continue...")
                    return
            except ValueError:
                print("❌ Invalid input. Please enter a number.")
                input("Press Enter to continue...")
                return

            # Collect order items
            from services.order_service import OrderItemData
            from decimal import Decimal

            items: List[OrderItemData] = []
            total: Decimal = Decimal('0')

            for i in range(num_items):
                print(f"\n--- Item {i + 1} ---")
                code: str = input("Product Code: ").strip()

                try:
                    product = self.product_service.get_product_by_code(code)
                except ValueError:
                    print(f"❌ Product code {code} not found")
                    continue

                try:
                    quantity: int = int(input("Quantity: "))
                    if quantity <= 0:
                        print("❌ Quantity must be positive")
                        continue
                except ValueError:
                    print("❌ Invalid quantity")
                    continue

                unit_price: Decimal = Decimal(str(product.price))
                subtotal: Decimal = Decimal(quantity) * unit_price
                total += subtotal

                items.append(OrderItemData(
                    product_id=product.id,
                    quantity=quantity,
                    unit_price=unit_price
                ))

                print(f"✓ Added: {product.name} x{quantity} = {format_currency(float(subtotal))}")

            if not items:
                print("\n❌ No items added to order")
                input("Press Enter to continue...")
                return

            # Display order summary
            print("\n" + "=" * 60)
            print("ORDER SUMMARY")
            print("=" * 60)
            print(f"Total Amount: {format_currency(float(total))}")

            # Get payment
            try:
                payment: float = float(input("\nAmount Paid: "))
                if payment <= 0:
                    print("❌ Payment must be positive")
                    input("Press Enter to continue...")
                    return
            except ValueError:
                print("❌ Invalid payment amount")
                input("Press Enter to continue...")
                return

            # Create order
            order_result = self.order_service.create_order(
                items=items,
                payment_amount=Decimal(str(payment))
            )

            # Display receipt
            self._print_receipt(order_result)

        except Exception as e:
            print(f"\n❌ Error creating order: {str(e)}")
            self.logger.error(f"Error in create_order: {str(e)}")
            input("Press Enter to continue...")

    def _print_receipt(self, order_result: dict) -> None:
        """Print order receipt.
        
        Args:
            order_result: Dictionary with order details.
        """
        clear_screen()
        print("=" * 60)
        print("RECEIPT".center(60))
        print("=" * 60)

        order = order_result["order"]
        items = order_result["items"]

        print(f"\nOrder Number: {order.order_number}")
        print(f"Date/Time: {order.created_at}")

        print("\n" + "-" * 60)
        print("Items:")
        print("-" * 60)

        for item in items:
            product = self.product_service.get_product_by_id(item.product_id)
            print(
                f"{product.name:30} x{item.quantity:3} @ {format_currency(float(item.unit_price)):>10} = {format_currency(float(item.subtotal)):>10}"
            )

        print("-" * 60)
        print(f"Total Amount:    {format_currency(order_result['total_amount']):>50}")
        print(f"Amount Paid:     {format_currency(order_result['payment_amount']):>50}")
        print(f"Change:          {format_currency(order_result['change_amount']):>50}")
        print("=" * 60)
        print("THANK YOU FOR SHOPPING!".center(60))
        print("=" * 60)

        input("\nPress Enter to continue...")

FILE: cli/product_menu.py
ISTRUZIONE: Importa: logging, services (ProductService), cli.ui_helpers (clear_screen, print_header, ask_continue, print_table, format_currency). Crea classe ProductMenu con __init__(self, product_service: ProductService, admin_id: int). Implementa metodi: display() (mostra menu prodotti), list_products() (mostra lista prodotti), add_product() (richiede code, name, unit, price, crea prodotto), update_product() (richiede product_id e nuovi valori), delete_product() (richiede product_id, elimina prodotto).

import logging
from typing import List
from services.product_service import ProductService
from cli.ui_helpers import clear_screen, print_header, ask_continue, print_table, format_currency


class ProductMenu:
    """Product management menu for administrators.
    
    Provides CRUD operations for product inventory.
    """

    def __init__(self, product_service: ProductService, admin_id: int) -> None:
        """Initialize ProductMenu with required services.
        
        Args:
            product_service: Service for product management.
            admin_id: ID of logged-in administrator.
        """
        self.product_service: ProductService = product_service
        self.admin_id: int = admin_id
        self.logger: logging.Logger = logging.getLogger(__name__)

    def display(self) -> None:
        """Display product menu and handle selections.
        
        Loops until user chooses to exit.
        """
        while True:
            clear_screen()
            print_header("PRODUCT MANAGEMENT")

            print("\n1) List Products")
            print("2) Add Product")
            print("3) Update Product")
            print("4) Delete Product")
            print("5) Search Product")
            print("6) Back to Admin Menu")

            choice: str = input("\nSelect option: ").strip()

            if choice == "1":
                self.list_products()
            elif choice == "2":
                self.add_product()
            elif choice == "3":
                self.update_product()
            elif choice == "4":
                self.delete_product()
            elif choice == "5":
                self.search_product()
            elif choice == "6":
                break
            else:
                print("\n❌ Invalid choice. Please select 1-6.")
                input("Press Enter to continue...")

    def list_products(self) -> None:
        """Display all products in a formatted table."""
        clear_screen()
        print_header("PRODUCT LIST")

        try:
            products = self.product_service.get_all_products()

            if not products:
                print("\nNo products found.")
                input("Press Enter to continue...")
                return

            headers: List[str] = ["ID", "Code", "Name", "Unit", "Price"]
            rows: List[List[str]] = [
                [
                    str(p.id),
                    p.code,
                    p.name,
                    p.unit,
                    format_currency(float(p.price))
                ]
                for p in products
            ]

            print()
            print_table(headers, rows)
            input("\nPress Enter to continue...")

        except Exception as e:
            print(f"\n❌ Error loading products: {str(e)}")
            self.logger.error(f"Error in list_products: {str(e)}")
            input("Press Enter to continue...")

    def add_product(self) -> None:
        """Add a new product."""
        clear_screen()
        print_header("ADD NEW PRODUCT")

        try:
            code: str = input("\nProduct Code (8 digits): ").strip()
            name: str = input("Product Name: ").strip()
            unit: str = input("Unit of Measurement: ").strip()

            try:
                price: float = float(input("Price: "))
            except ValueError:
                print("❌ Invalid price format")
                input("Press Enter to continue...")
                return

            product = self.product_service.create_product(
                code=code,
                name=name,
                unit=unit,
                price=price,
                admin_id=self.admin_id
            )

            print(f"\n✓ Product created successfully!")
            print(f"  Code: {product.code}")
            print(f"  Name: {product.name}")
            print(f"  Unit: {product.unit}")
            print(f"  Price: {format_currency(float(product.price))}")

            if ask_continue("\nAdd another product? [Y/N]: "):
                self.add_product()

        except ValueError as e:
            print(f"\n❌ Error: {str(e)}")
            self.logger.warning(f"Product creation failed: {str(e)}")
            input("Press Enter to continue...")
        except Exception as e:
            print(f"\n❌ Unexpected error: {str(e)}")
            self.logger.error(f"Error in add_product: {str(e)}")
            input("Press Enter to continue...")

    def update_product(self) -> None:
        """Update an existing product."""
        clear_screen()
        print_header("UPDATE PRODUCT")

        try:
            # List products first
            products = self.product_service.get_all_products()
            if not products:
                print("\nNo products to update.")
                input("Press Enter to continue...")
                return

            try:
                product_id: int = int(input("\nEnter Product ID to update: "))
            except ValueError:
                print("❌ Invalid product ID")
                input("Press Enter to continue...")
                return

            product = self.product_service.get_product_by_id(product_id)

            print(f"\nCurrent Product:")
            print(f"  Code: {product.code}")
            print(f"  Name: {product.name}")
            print(f"  Unit: {product.unit}")
            print(f"  Price: {format_currency(float(product.price))}")

            print("\nEnter new values (leave blank to keep current):")

            updates: dict = {}

            new_code: str = input("New Code: ").strip()
            if new_code:
                updates["code"] = new_code

            new_name: str = input("New Name: ").strip()
            if new_name:
                updates["name"] = new_name

            new_unit: str = input("New Unit: ").strip()
            if new_unit:
                updates["unit"] = new_unit

            new_price: str = input("New Price: ").strip()
            if new_price:
                try:
                    updates["price"] = float(new_price)
                except ValueError:
                    print("❌ Invalid price format")
                    input("Press Enter to continue...")
                    return

            if not updates:
                print("\nNo changes made.")
                input("Press Enter to continue...")
                return

            updated_product = self.product_service.update_product(
                product_id=product_id,
                admin_id=self.admin_id,
                **updates
            )

            print(f"\n✓ Product updated successfully!")
            print(f"  Code: {updated_product.code}")
            print(f"  Name: {updated_product.name}")
            print(f"  Unit: {updated_product.unit}")
            print(f"  Price: {format_currency(float(updated_product.price))}")

            input("Press Enter to continue...")

        except ValueError as e:
            print(f"\n❌ Error: {str(e)}")
            self.logger.warning(f"Product update failed: {str(e)}")
            input("Press Enter to continue...")
        except Exception as e:
            print(f"\n❌ Unexpected error: {str(e)}")
            self.logger.error(f"Error in update_product: {str(e)}")
            input("Press Enter to continue...")

    def delete_product(self) -> None:
        """Delete a product."""
        clear_screen()
        print_header("DELETE PRODUCT")

        try:
            # List products first
            products = self.product_service.get_all_products()
            if not products:
                print("\nNo products to delete.")
                input("Press Enter to continue...")
                return

            try:
                product_id: int = int(input("\nEnter Product ID to delete: "))
            except ValueError:
                print("❌ Invalid product ID")
                input("Press Enter to continue...")
                return

            product = self.product_service.get_product_by_id(product_id)

            print(f"\nProduct to delete:")
            print(f"  Code: {product.code}")
            print(f"  Name: {product.name}")
            print(f"  Unit: {product.unit}")
            print(f"  Price: {format_currency(float(product.price))}")

            if ask_continue("\nAre you sure you want to delete this product? [Y/N]: "):
                self.product_service.delete_product(product_id, self.admin_id)
                print("\n✓ Product deleted successfully!")
                self.logger.info(f"Product {product_id} deleted by admin {self.admin_id}")

            input("Press Enter to continue...")

        except ValueError as e:
            print(f"\n❌ Error: {str(e)}")
            self.logger.warning(f"Product deletion failed: {str(e)}")
            input("Press Enter to continue...")
        except Exception as e:
            print(f"\n❌ Unexpected error: {str(e)}")
            self.logger.error(f"Error in delete_product: {str(e)}")
            input("Press Enter to continue...")

    def search_product(self) -> None:
        """Search for products by name."""
        clear_screen()
        print_header("SEARCH PRODUCTS")

        try:
            search_term: str = input("\nEnter product name to search: ").strip()

            if not search_term:
                print("❌ Search term cannot be empty")
                input("Press Enter to continue...")
                return

            products = self.product_service.search_products_by_name(search_term)

            if not products:
                print(f"\nNo products found matching '{search_term}'")
                input("Press Enter to continue...")
                return

            headers: List[str] = ["ID", "Code", "Name", "Unit", "Price"]
            rows: List[List[str]] = [
                [
                    str(p.id),
                    p.code,
                    p.name,
                    p.unit,
                    format_currency(float(p.price))
                ]
                for p in products
            ]

            print()
            print_table(headers, rows)
            input("\nPress Enter to continue...")

        except Exception as e:
            print(f"\n❌ Error: {str(e)}")
            self.logger.error(f"Error in search_product: {str(e)}")
            input("Press Enter to continue...")

FILE: cli/employee_menu.py
ISTRUZIONE: Importa: logging, services (EmployeeService), cli.ui_helpers (clear_screen, print_header, ask_continue, print_table, format_currency). Crea classe EmployeeMenu con __init__(self, employee_service: EmployeeService, admin_id: int). Implementa metodi: display() (mostra menu dipendenti), list_employees() (mostra lista dipendenti), add_employee() (crea dipendente), calculate_salary() (richiede employee_id e ore, calcola stipendio).

import logging
from typing import List
from services.employee_service import EmployeeService
from cli.ui_helpers import clear_screen, print_header, ask_continue, print_table, format_currency


class EmployeeMenu:
    """Employee management menu for administrators.
    
    Provides employee CRUD and salary calculation operations.
    """

    def __init__(self, employee_service: EmployeeService, admin_id: int) -> None:
        """Initialize EmployeeMenu with required services.
        
        Args:
            employee_service: Service for employee management.
            admin_id: ID of logged-in administrator.
        """
        self.employee_service: EmployeeService = employee_service
        self.admin_id: int = admin_id
        self.logger: logging.Logger = logging.getLogger(__name__)

    def display(self) -> None:
        """Display employee menu and handle selections.
        
        Loops until user chooses to exit.
        """
        while True:
            clear_screen()
            print_header("EMPLOYEE MANAGEMENT")

            print("\n1) List Employees")
            print("2) Add Employee")
            print("3) Calculate Salary")
            print("4) Back to Admin Menu")

            choice: str = input("\nSelect option: ").strip()

            if choice == "1":
                self.list_employees()
            elif choice == "2":
                self.add_employee()
            elif choice == "3":
                self.calculate_salary()
            elif choice == "4":
                break
            else:
                print("\n❌ Invalid choice. Please select 1-4.")
                input("Press Enter to continue...")

    def list_employees(self) -> None:
        """Display all employees in a formatted table."""
        clear_screen()
        print_header("EMPLOYEE LIST")

        try:
            employees = self.employee_service.list_all_employees()

            if not employees:
                print("\nNo employees found.")
                input("Press Enter to continue...")
                return

            headers: List[str] = ["ID", "Name", "Employee ID", "Hourly Rate"]
            rows: List[List[str]] = [
                [
                    str(e.id),
                    e.name,
                    e.employee_id,
                    format_currency(float(e.hourly_rate))
                ]
                for e in employees
            ]

            print()
            print_table(headers, rows)
            input("\nPress Enter to continue...")

        except Exception as e:
            print(f"\n❌ Error loading employees: {str(e)}")
            self.logger.error(f"Error in list_employees: {str(e)}")
            input("Press Enter to continue...")

    def add_employee(self) -> None:
        """Add a new employee."""
        clear_screen()
        print_header("ADD NEW EMPLOYEE")

        try:
            name: str = input("\nEmployee Name: ").strip()
            employee_id: str = input("Employee ID: ").strip()

            hourly_rate_input: str = input("Hourly Rate (default 500.00): ").strip()
            hourly_rate: float = 500.0

            if hourly_rate_input:
                try:
                    hourly_rate = float(hourly_rate_input)
                except ValueError:
                    print("❌ Invalid hourly rate format")
                    input("Press Enter to continue...")
                    return

            employee = self.employee_service.create_employee(
                name=name,
                employee_id=employee_id,
                hourly_rate=hourly_rate
            )

            print(f"\n✓ Employee created successfully!")
            print(f"  Name: {employee.name}")
            print(f"  Employee ID: {employee.employee_id}")
            print(f"  Hourly Rate: {format_currency(float(employee.hourly_rate))}")

            if ask_continue("\nAdd another employee? [Y/N]: "):
                self.add_employee()

        except ValueError as e:
            print(f"\n❌ Error: {str(e)}")
            self.logger.warning(f"Employee creation failed: {str(e)}")
            input("Press Enter to continue...")
        except Exception as e:
            print(f"\n❌ Unexpected error: {str(e)}")
            self.logger.error(f"Error in add_employee: {str(e)}")
            input("Press Enter to continue...")

    def calculate_salary(self) -> None:
        """Calculate salary for an employee.
        
        Implements: SALARY = HOURLY_RATE × HOURS_WORKED
        """
        clear_screen()
        print_header("CALCULATE SALARY")

        try:
            # List employees first
            employees = self.employee_service.list_all_employees()
            if not employees:
                print("\nNo employees found.")
                input("Press Enter to continue...")
                return

            print("\nAvailable Employees:")
            for e in employees:
                print(f"  ID {e.id}: {e.name} ({e.employee_id}) - {format_currency(float(e.hourly_rate))}/hour")

            try:
                employee_id: int = int(input("\nEnter Employee ID: "))
            except ValueError:
                print("❌ Invalid employee ID")
                input("Press Enter to continue...")
                return

            employee = self.employee_service.get_employee_by_id(employee_id)

            try:
                hours_worked: float = float(input("Hours Worked: "))
            except ValueError:
                print("❌ Invalid hours format")
                input("Press Enter to continue...")
                return

            salary_record = self.employee_service.calculate_salary(
                employee_id=employee_id,
                hours_worked=hours_worked,
                admin_id=self.admin_id
            )

            print(f"\n✓ Salary calculated successfully!")
            print(f"  Employee: {employee.name}")
            print(f"  Hours Worked: {salary_record.hours_worked}")
            print(f"  Hourly Rate: {format_currency(float(salary_record.hourly_rate))}")
            print(f"  Total Salary: {format_currency(float(salary_record.total_salary))}")

            if ask_continue("\nCalculate another salary? [Y/N]: "):
                self.calculate_salary()

        except ValueError as e:
            print(f"\n❌ Error: {str(e)}")
            self.logger.warning(f"Salary calculation failed: {str(e)}")
            input("Press Enter to continue...")
        except Exception as e:
            print(f"\n❌ Unexpected error: {str(e)}")
            self.logger.error(f"Error in calculate_salary: {str(e)}")
            input("Press Enter to continue...")

FILE: cli/profit_menu.py
ISTRUZIONE: Importa: logging, services (ProfitService), cli.ui_helpers (clear_screen, print_header, ask_continue, print_table, format_currency). Crea classe ProfitMenu con __init__(self, profit_service: ProfitService, admin_id: int). Implementa metodi: display() (mostra menu profitti), calculate_profit() (richiede COGS e selling_price, calcola PROFIT = SELLING_PRICE - COGS), list_profits() (mostra lista profitti calcolati).

import logging
from typing import List
from services.profit_service import ProfitService
from cli.ui_helpers import clear_screen, print_header, ask_continue, print_table, format_currency


class ProfitMenu:
    """Profit management menu for administrators.
    
    Provides profit calculation and viewing operations.
    """

    def __init__(self, profit_service: ProfitService, admin_id: int) -> None:
        """Initialize ProfitMenu with required services.
        
        Args:
            profit_service: Service for profit calculation.
            admin_id: ID of logged-in administrator.
        """
        self.profit_service: ProfitService = profit_service
        self.admin_id: int = admin_id
        self.logger: logging.Logger = logging.getLogger(__name__)

    def display(self) -> None:
        """Display profit menu and handle selections.
        
        Loops until user chooses to exit.
        """
        while True:
            clear_screen()
            print_header("PROFIT MANAGEMENT")

            print("\n1) Calculate Profit")
            print("2) View Profit History")
            print("3) Back to Admin Menu")

            choice: str = input("\nSelect option: ").strip()

            if choice == "1":
                self.calculate_profit()
            elif choice == "2":
                self.list_profits()
            elif choice == "3":
                break
            else:
                print("\n❌ Invalid choice. Please select 1-3.")
                input("Press Enter to continue...")

    def calculate_profit(self) -> None:
        """Calculate profit.
        
        Implements: PROFIT = SELLING_PRICE - COGS
        """
        clear_screen()
        print_header("CALCULATE PROFIT")

        try:
            try:
                cogs: float = float(input("\nCost of Goods Sold (COGS): "))
            except ValueError:
                print("❌ Invalid COGS format")
                input("Press Enter to continue...")
                return

            try:
                selling_price: float = float(input("Selling Price: "))
            except ValueError:
                print("❌ Invalid selling price format")
                input("Press Enter to continue...")
                return

            profit_record = self.profit_service.calculate_profit(
                cogs=cogs,
                selling_price=selling_price,
                admin_id=self.admin_id
            )

            print(f"\n✓ Profit calculated successfully!")
            print(f"  COGS: {format_currency(float(profit_record.cogs))}")
            print(f"  Selling Price: {format_currency(float(profit_record.selling_price))}")
            print(f"  Profit: {format_currency(float(profit_record.profit))}")

            if ask_continue("\nCalculate another profit? [Y/N]: "):
                self.calculate_profit()

        except ValueError as e:
            print(f"\n❌ Error: {str(e)}")
            self.logger.warning(f"Profit calculation failed: {str(e)}")
            input("Press Enter to continue...")
        except Exception as e:
            print(f"\n❌ Unexpected error: {str(e)}")
            self.logger.error(f"Error in calculate_profit: {str(e)}")
            input("Press Enter to continue...")

    def list_profits(self) -> None:
        """Display all profit records in a formatted table."""
        clear_screen()
        print_header("PROFIT HISTORY")

        try:
            profits = self.profit_service.list_all_profits()

            if not profits:
                print("\nNo profit records found.")
                input("Press Enter to continue...")
                return

            headers: List[str] = ["ID", "COGS", "Selling Price", "Profit", "Date"]
            rows: List[List[str]] = [
                [
                    str(p.id),
                    format_currency(float(p.cogs)),
                    format_currency(float(p.selling_price)),
                    format_currency(float(p.profit)),
                    str(p.created_at)
                ]
                for p in profits
            ]

            print()
            print_table(headers, rows)
            input("\nPress Enter to continue...")

        except Exception as e:
            print(f"\n❌ Error loading profit records: {str(e)}")
            self.logger.error(f"Error in list_profits: {str(e)}")
            input("Press Enter to continue...")

FILE: cli/order_menu.py
ISTRUZIONE: Importa: logging, services (OrderService), cli.ui_helpers (clear_screen, print_header, print_table, format_currency). Crea classe OrderMenu con __init__(self, order_service: OrderService). Implementa metodi: display() (mostra menu ordini), list_orders() (mostra lista ordini), view_order_receipt() (mostra ricevuta ordine).

import logging
from typing import List
from services.order_service import OrderService
from cli.ui_helpers import clear_screen, print_header, print_table, format_currency


class OrderMenu:
    """Order viewing menu for administrators.
    
    Provides order history and receipt viewing operations.
    """

    def __init__(self, order_service: OrderService) -> None:
        """Initialize OrderMenu with required services.
        
        Args:
            order_service: Service for order management.
        """
        self.order_service: OrderService = order_service
        self.logger: logging.Logger = logging.getLogger(__name__)

    def display(self) -> None:
        """Display order menu and handle selections.
        
        Loops until user chooses to exit.
        """
        while True:
            clear_screen()
            print_header("ORDER MANAGEMENT")

            print("\n1) View All Orders")
            print("2) View Order Receipt")
            print("3) Back to Admin Menu")

            choice: str = input("\nSelect option: ").strip()

            if choice == "1":
                self.list_orders()
            elif choice == "2":
                self.view_order_receipt()
            elif choice == "3":
                break
            else:
                print("\n❌ Invalid choice. Please select 1-3.")
                input("Press Enter to continue...")

    def list_orders(self) -> None:
        """Display all orders in a formatted table."""
        clear_screen()
        print_header("ORDER HISTORY")

        try:
            orders = self.order_service.list_all_orders()

            if not orders:
                print("\nNo orders found.")
                input("Press Enter to continue...")
                return

            headers: List[str] = ["Order #", "Total", "Paid", "Change", "Date"]
            rows: List[List[str]] = [
                [
                    o.order_number,
                    format_currency(float(o.total_amount)),
                    format_currency(float(o.payment_amount)),
                    format_currency(float(o.change_amount)),
                    str(o.created_at)
                ]
                for o in orders
            ]

            print()
            print_table(headers, rows)
            input("\nPress Enter to continue...")

        except Exception as e:
            print(f"\n❌ Error loading orders: {str(e)}")
            self.logger.error(f"Error in list_orders: {str(e)}")
            input("Press Enter to continue...")

    def view_order_receipt(self) -> None:
        """Display a specific order receipt."""
        clear_screen()
        print_header("VIEW ORDER RECEIPT")

        try:
            try:
                order_id: int = int(input("\nEnter Order ID: "))
            except ValueError:
                print("❌ Invalid order ID")
                input("Press Enter to continue...")
                return

            receipt = self.order_service.get_order_receipt(order_id)

            self._print_receipt(receipt)

        except ValueError as e:
            print(f"\n❌ Error: {str(e)}")
            self.logger.warning(f"Receipt retrieval failed: {str(e)}")
            input("Press Enter to continue...")
        except Exception as e:
            print(f"\n❌ Unexpected error: {str(e)}")
            self.logger.error(f"Error in view_order_receipt: {str(e)}")
            input("Press Enter to continue...")

    def _print_receipt(self, receipt: dict) -> None:
        """Print order receipt.
        
        Args:
            receipt: Dictionary with order details.
        """
        clear_screen()
        print("=" * 70)
        print("RECEIPT".center(70))
        print("=" * 70)

        print(f"\nOrder Number: {receipt['order_number']}")
        print(f"Date/Time: {receipt['created_at']}")

        print("\n" + "-" * 70)
        print("Items:")
        print("-" * 70)

        for item in receipt["items"]:
            print(
                f"Product ID {item.product_id:3} x{item.quantity:3} @ {format_currency(float(item.unit_price)):>10} = {format_currency(float(item.subtotal)):>10}"
            )

        print("-" * 70)
        print(f"Total Amount:    {format_currency(receipt['total_amount']):>55}")
        print(f"Amount Paid:     {format_currency(receipt['payment_amount']):>55}")
        print(f"Change:          {format_currency(receipt['change_amount']):>55}")
        print("=" * 70)
        print("THANK YOU FOR SHOPPING!".center(70))
        print("=" * 70)

        input("\nPress Enter to continue...")

FILE: main.py
ISTRUZIONE: Importa: logging, logging.handlers (RotatingFileHandler), config (Config), database.connection (DatabaseConnection), database.init_db (init_database), repositories (ProductRepository, AdminRepository, EmployeeRepository, OrderRepository, OrderItemRepository, SalaryRepository, ProfitRepository, ActivityLogRepository), services (AuthService, ProductService, EmployeeService, OrderService, ProfitService, ActivityService), cli.main_menu (MainMenu). Crea funzione setup_logging() che configura logging con RotatingFileHandler. Crea funzione main() che: 1) valida config, 2) setup logging, 3) inizializza database, 4) crea repositories, 5) crea services, 6) crea MainMenu e chiama display(). Crea if __name__ == "__main__": main().

import logging
import logging.handlers
from config import Config
from database.connection import DatabaseConnection
from database.init_db import init_database
from repositories.product_repository import ProductRepository
from repositories.admin_repository import AdminRepository
from repositories.employee_repository import EmployeeRepository
from repositories.order_repository import OrderRepository
from repositories.order_item_repository import OrderItemRepository
from repositories.salary_repository import SalaryRepository
from repositories.profit_repository import ProfitRepository
from repositories.activity_log_repository import ActivityLogRepository
from services.auth_service import AuthService
from services.product_service import ProductService
from services.employee_service import EmployeeService
from services.order_service import OrderService
from services.profit_service import ProfitService
from services.activity_service import ActivityService
from cli.main_menu import MainMenu


def setup_logging() -> None:
    """Configure logging with rotating file handler.
    
    Sets up logging to both console and file with appropriate formatting.
    """
    # Create logs directory if it doesn't exist
    import os
    os.makedirs("logs", exist_ok=True)

    # Configure root logger
    logger: logging.Logger = logging.getLogger()
    logger.setLevel(Config.LOG_LEVEL)

    # File handler with rotation
    file_handler: logging.handlers.RotatingFileHandler = (
        logging.handlers.RotatingFileHandler(
            Config.LOG_FILE,
            maxBytes=10485760,  # 10MB
            backupCount=5
        )
    )
    file_handler.setLevel(Config.LOG_LEVEL)

    # Console handler
    console_handler: logging.StreamHandler = logging.StreamHandler()
    console_handler.setLevel(logging.WARNING)

    # Formatter
    formatter: logging.Formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    # Add handlers to root logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    logger.info("Logging initialized")


def main() -> None:
    """Main application entry point.
    
    Initializes configuration, database, repositories, services,
    and starts the CLI interface.
    """
    try:
        # Validate configuration
        Config.validate()

        # Setup logging
        setup_logging()
        logger: logging.Logger = logging.getLogger(__name__)
        logger.info("Application starting...")

        # Initialize database connection
        DatabaseConnection.initialize()
        logger.info("Database connection initialized")

        # Initialize database (create tables and seed data)
        init_database()
        logger.info("Database initialized")

        # Get database session
        session = DatabaseConnection.get_session()

        # Initialize repositories
        product_repo: ProductRepository = ProductRepository(session)
        admin_repo: AdminRepository = AdminRepository(session)
        employee_repo: EmployeeRepository = EmployeeRepository(session)
        order_repo: OrderRepository = OrderRepository(session)
        order_item_repo: OrderItemRepository = OrderItemRepository(session)
        salary_repo: SalaryRepository = SalaryRepository(session)
        profit_repo: ProfitRepository = ProfitRepository(session)
        activity_log_repo: ActivityLogRepository = ActivityLogRepository(session)

        logger.info("Repositories initialized")

        # Initialize services
        activity_service: ActivityService = ActivityService(activity_log_repo)
        auth_service: AuthService = AuthService(admin_repo)
        product_service: ProductService = ProductService(product_repo, activity_service)
        employee_service: EmployeeService = EmployeeService(
            employee_repo, salary_repo, activity_service
        )
        order_service: OrderService = OrderService(
            order_repo, order_item_repo, product_repo, activity_service
        )
        profit_service: ProfitService = ProfitService(profit_repo, activity_service)

        logger.info("Services initialized")

        # Create and display main menu
        main_menu: MainMenu = MainMenu(auth_service, product_service)
        main_menu.display()

        # Cleanup
        DatabaseConnection.close_session(session)
        logger.info("Application terminated normally")

    except ValueError as e:
        print(f"Configuration Error: {str(e)}")
        logging.error(f"Configuration error: {str(e)}")
        exit(1)
    except Exception as e:
        print(f"Fatal Error: {str(e)}")
        logging.error(f"Fatal error: {str(e)}", exc_info=True)
        exit(1)


if __name__ == "__main__":
    main()

FILE: .env
ISTRUZIONE: Crea file .env con variabili di ambiente per database, logging, admin email.

DB_HOST=localhost
DB_PORT=5432
DB_NAME=supermarket_db
DB_USER=postgres
DB_PASSWORD=your_secure_password
LOG_LEVEL=INFO
ADMIN_EMAIL=robby@gmail.com

FILE: requirements.txt
ISTRUZIONE: Già generato in precedenza, ma ripeti per completezza.

sqlalchemy==2.0.23
psycopg2-binary==2.9.9
bcrypt==4.1.1
python-dotenv==1.0.0
colorama==0.4.6