import logging
import logging.handlers
from config import Config
from database.connection import DatabaseConnection
from database.init_db import init_database
from repositories.product_repository import ProductRepository
from repositories.admin_repository import AdminRepository
from repositories.employee_repository import EmployeeRepository
from repositories.order_repository import OrderRepository
from repositories.order_item_repository import OrderItemRepository
from repositories.salary_repository import SalaryRepository
from repositories.profit_repository import ProfitRepository
from repositories.activity_log_repository import ActivityLogRepository
from services.auth_service import AuthService
from services.product_service import ProductService
from services.employee_service import EmployeeService
from services.order_service import OrderService
from services.profit_service import ProfitService
from services.activity_service import ActivityService
from cli.main_menu import MainMenu
from cli.admin_menu import AdminMenu


def setup_logging() -> None:
    """Configure logging with rotating file handler.
    
    Sets up logging to both console and file with appropriate formatting.
    """
    import os
    os.makedirs("logs", exist_ok=True)

    logger: logging.Logger = logging.getLogger()
    logger.setLevel(Config.LOG_LEVEL)

    file_handler: logging.handlers.RotatingFileHandler = (
        logging.handlers.RotatingFileHandler(
            Config.LOG_FILE,
            maxBytes=10485760,
            backupCount=5
        )
    )
    file_handler.setLevel(Config.LOG_LEVEL)

    console_handler: logging.StreamHandler = logging.StreamHandler()
    console_handler.setLevel(logging.WARNING)

    formatter: logging.Formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    logger.info("Logging initialized")


def main() -> None:
    """Main application entry point.
    
    Initializes configuration, database, repositories, services,
    and starts the CLI interface.
    """
    try:
        Config.validate()

        setup_logging()
        logger: logging.Logger = logging.getLogger(__name__)
        logger.info("Application starting...")

        DatabaseConnection.initialize()
        logger.info("Database connection initialized")

        init_database()
        logger.info("Database initialized")

        session = DatabaseConnection.get_session()

        product_repo: ProductRepository = ProductRepository(session)
        admin_repo: AdminRepository = AdminRepository(session)
        employee_repo: EmployeeRepository = EmployeeRepository(session)
        order_repo: OrderRepository = OrderRepository(session)
        order_item_repo: OrderItemRepository = OrderItemRepository(session)
        salary_repo: SalaryRepository = SalaryRepository(session)
        profit_repo: ProfitRepository = ProfitRepository(session)
        activity_log_repo: ActivityLogRepository = ActivityLogRepository(session)

        logger.info("Repositories initialized")

        activity_service: ActivityService = ActivityService(activity_log_repo)
        auth_service: AuthService = AuthService(admin_repo)
        product_service: ProductService = ProductService(product_repo, activity_service)
        employee_service: EmployeeService = EmployeeService(
            employee_repo, salary_repo, activity_service
        )
        order_service: OrderService = OrderService(
            order_repo, order_item_repo, product_repo, activity_service
        )
        profit_service: ProfitService = ProfitService(profit_repo, activity_service)

        logger.info("Services initialized")

        main_menu: MainMenu = MainMenu(auth_service, product_service)

        original_admin_login = main_menu._admin_login

        def enhanced_admin_login() -> None:
            """Enhanced admin login that passes services to AdminMenu."""
            from cli.ui_helpers import clear_screen, print_header
            
            clear_screen()
            print_header("ADMINISTRATOR LOGIN")

            email: str = input("\nEmail: ").strip()
            password: str = input("Password: ").strip()

            try:
                admin = auth_service.authenticate(email, password)
                print(f"\n✓ Welcome, {admin.email}!")
                input("Press Enter to continue...")

                admin_menu = AdminMenu(
                    auth_service=auth_service,
                    product_service=product_service,
                    employee_service=employee_service,
                    profit_service=profit_service,
                    admin_id=admin.id
                )
                admin_menu.display()

            except ValueError as e:
                print(f"\n❌ Login failed: {str(e)}")
                logger.warning(f"Failed login attempt for email: {email}")
                input("Press Enter to continue...")

        main_menu._admin_login = enhanced_admin_login

        main_menu.display()

        DatabaseConnection.close_session(session)
        logger.info("Application terminated normally")

    except ValueError as e:
        print(f"Configuration Error: {str(e)}")
        logging.error(f"Configuration error: {str(e)}")
        exit(1)
    except Exception as e:
        print(f"Fatal Error: {str(e)}")
        logging.error(f"Fatal error: {str(e)}", exc_info=True)
        exit(1)


if __name__ == "__main__":
    main()